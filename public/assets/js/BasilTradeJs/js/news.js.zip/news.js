const API_TOKEN = 'jsIyHk2noX7pokbVBn6vDfYVygYAcweEW5LMxKxz'; // Replace with your actual API token
const BASE_URL = 'https://api.marketaux.com/v1/news/all';
const SIMILAR_NEWS_URL = 'https://api.marketaux.com/v1/news/similar';

const ARTICLES_PER_LOAD_DEFAULT = 12; // Default for most sections
const ARTICLES_PER_LOAD_PREDICTION = 5; // Specific for Prediction & Analysis

const mainNewsContainer = document.getElementById('business-news-container');
const predictionAnalysisContainer = document.getElementById('prediction-analysis-container');
const newsCategoryHeading = document.getElementById('news-category-heading');

const economyNewsContainer = document.getElementById('economy-news-container');
const technologyNewsContainer = document.getElementById('technology-news-container');
const startupsNewsContainer = document.getElementById('startups-news-container');

const newsOffsets = {
    main: 0,
    economy: 0,
    technology: 0,
    startups: 0,
    prediction: 0
};

const newsSearchTerms = {
    main: "India",
    economy: "Economy India",
    technology: "Technology India",
    startups: "Startups India",
    prediction: "market prediction analysis India"
};

async function fetchNews(containerElement, searchTerm = null, limit, offset = 0) {
    if (offset === 0 && containerElement) {
        containerElement.innerHTML = '<p class="text-gray-600">Loading news...</p>';
    }

    let apiUrl = `${BASE_URL}?filter_entities=true&language=en&limit=${limit}&offset=${offset}&api_token=${API_TOKEN}&sort=published_at:desc`;

    if (searchTerm && searchTerm.trim() !== "") {
        apiUrl += `&search=${encodeURIComponent(searchTerm.trim())}`;
    }

    try {
        const response = await fetch(apiUrl);
        if (!response.ok) {
            const errorText = await response.text();
            console.error('Error fetching news:', response.status, errorText, 'URL:', apiUrl);
            if (offset === 0 && containerElement) {
                containerElement.innerHTML = '<p class="text-red-600">Error loading news. Please try again later.</p>';
            } else if (containerElement) {
                console.error('Error loading more news:', response.status, errorText);
            }
            return [];
        }
        const data = await response.json();
        return data.data || [];
    } catch (error) {
        console.error('Error fetching news:', error);
        if (offset === 0 && containerElement) {
            containerElement.innerHTML = '<p class="text-red-600">Failed to fetch news. Network error or invalid API key.</p>';
        } else if (containerElement) {
            console.error('Failed to fetch more news:', error);
        }
        return [];
    }
}

async function fetchSimilarNews(uuid) {
    const url = `${SIMILAR_NEWS_URL}/${uuid}?api_token=${API_TOKEN}&language=en`;
    try {
        const response = await fetch(url);
        if (!response.ok) {
            const errorText = await response.text();
            console.error('Error fetching similar news:', response.status, errorText);
            return [];
        }
        const data = await response.json();
        return data.data || [];
    } catch (error) {
        console.error('Error fetching similar news:', error);
        return [];
    }
}

function renderNews(articles, containerElement, isDetailedView = false, append = false) {
    if (!append) {
        containerElement.innerHTML = '';
    }

    if (articles.length === 0 && !append) {
        containerElement.innerHTML = '<p class="text-gray-600">No news found for this selection.</p>';
        return;
    } else if (articles.length === 0 && append) {
        const loadMoreButton = containerElement.nextElementSibling;
        if (loadMoreButton && loadMoreButton.classList.contains('load-more-button')) {
            loadMoreButton.classList.add('hidden');
        }
        return;
    }

    articles.forEach(article => {
        const newsItem = document.createElement('div');
        const layoutClasses = containerElement === predictionAnalysisContainer ?
            [ 'rounded-lg', 'shadow-sm', 'overflow-hidden', 'hover:shadow-md', 'transition', 'duration-200', 'cursor-pointer'] :
            ['news_conta','bg-[#3B896D]', 'p-4', 'rounded-lg', 'shadow-sm','w-[500px]','h-30', 'flex','gap-6','hover:bg-[#66cc99]' ,'items-center', 'space-x-4', 'hover:shadow-lg', 'transition', 'duration-200', 'cursor-pointer'];

        newsItem.classList.add(...layoutClasses);

        newsItem.addEventListener('click', () => {
            sessionStorage.setItem('currentArticle', JSON.stringify(article));
            window.location.href = `news_details?uuid=${article.uuid}`;
        });

        const imageUrl = article.image_url && article.image_url.startsWith('http') ? article.image_url :
            (containerElement === predictionAnalysisContainer ? 'https://placehold.co/400x250/e2e8f0/000?text=Article+Image' :
                'https://placehold.co/100x80/e2e8f0/000?text=News+Image');

        const content = isDetailedView ?
            (article.description || article.snippet || 'No detailed description available.') :
            (article.snippet ? article.snippet.substring(0, 150) + '...' : 'No snippet available.');

        if (containerElement === predictionAnalysisContainer) {
            newsItem.innerHTML = `
                <img src="${imageUrl}" alt="Article Image" class="w-full h-40 object-cover" onerror="this.onerror=null; this.src='https://placehold.co/400x250/e2e8f0/000?text=No+Image';">
                <div class="p-4 mt-2">
                    <h3 class="font-semibold  text-white">${article.title}</h3>
                    <p class="text-gray-300 text-sm mt-2 ">${new Date(article.published_at).toLocaleDateString()}</p>
                </div>
            `;
        } else {
            newsItem.innerHTML = `
                <img src="${imageUrl}" alt="News Image" class="w-24 h-20 object-cover rounded" onerror="this.onerror=null; this.src='https://placehold.co/100x80/e2e8f0/000?text=No+Image';">
                <div>
                    <h3 class="font-semibold text-white">${article.title}</h3>
                    <p class="text-gray-300 text-sm mt-1">Published by ${article.source} on ${new Date(article.published_at).toLocaleDateString()}</p>
                    <p class="text-gray-400 text-sm mt-2 para">${content}</p>
                    <span class="text-white hover:underline text-sm mt-2 inline-block para">Read more</span>
                </div>
            `;
        }
        containerElement.appendChild(newsItem);
    });
}

async function loadMoreNews(containerElement, sectionName) {
    const loadMoreButton = containerElement.nextElementSibling;
    if (loadMoreButton && loadMoreButton.classList.contains('load-more-button')) {
        loadMoreButton.textContent = 'Loading...';
        loadMoreButton.disabled = true;
    }

    newsOffsets[sectionName] += (sectionName === 'prediction' ? ARTICLES_PER_LOAD_PREDICTION : ARTICLES_PER_LOAD_DEFAULT);
    const searchTerm = newsSearchTerms[sectionName];
    const articles = await fetchNews(containerElement, searchTerm, (sectionName === 'prediction' ? ARTICLES_PER_LOAD_PREDICTION : ARTICLES_PER_LOAD_DEFAULT), newsOffsets[sectionName]);

    renderNews(articles, containerElement, false, true);

    if (loadMoreButton && loadMoreButton.classList.contains('load-more-button')) {
        loadMoreButton.textContent = 'Load More';
        loadMoreButton.disabled = false;
        if (articles.length < (sectionName === 'prediction' ? ARTICLES_PER_LOAD_PREDICTION : ARTICLES_PER_LOAD_DEFAULT)) {
            loadMoreButton.classList.add('hidden');
        }
    }
}


document.addEventListener('DOMContentLoaded', () => {
    if (mainNewsContainer) {
        const newsDropdownLinks = document.querySelectorAll('.dropdown-menu a[data-category]');

        newsDropdownLinks.forEach(link => {
            link.addEventListener('click', async (event) => {
                event.preventDefault();
                const categoryName = event.target.dataset.category;

                if (newsCategoryHeading) {
                    newsCategoryHeading.textContent = `${categoryName.toUpperCase()} NEWS`;
                }

                newsOffsets.main = 0;
                newsSearchTerms.main = categoryName;

                const articles = await fetchNews(mainNewsContainer, newsSearchTerms.main, ARTICLES_PER_LOAD_DEFAULT, newsOffsets.main);
                renderNews(articles, mainNewsContainer);

                const loadMoreButton = document.getElementById('load-more-main');
                if (loadMoreButton) {
                    if (articles.length === ARTICLES_PER_LOAD_DEFAULT) {
                        loadMoreButton.classList.remove('hidden');
                    } else {
                        loadMoreButton.classList.add('hidden');
                    }
                }
            });
        });

        let defaultHeading = "INDIA NEWS";
        if (newsCategoryHeading) {
            newsCategoryHeading.textContent = defaultHeading;
        }
        fetchNews(mainNewsContainer, newsSearchTerms.main, ARTICLES_PER_LOAD_DEFAULT, newsOffsets.main).then(articles => {
            renderNews(articles, mainNewsContainer);
            const loadMoreButton = document.getElementById('load-more-main');
            if (loadMoreButton) {
                if (articles.length === ARTICLES_PER_LOAD_DEFAULT) {
                    loadMoreButton.classList.remove('hidden');
                } else {
                    loadMoreButton.classList.add('hidden');
                }
            }
        });
    }

    if (economyNewsContainer) {
        fetchNews(economyNewsContainer, newsSearchTerms.economy, ARTICLES_PER_LOAD_DEFAULT, newsOffsets.economy).then(articles => {
            renderNews(articles, economyNewsContainer);
            const loadMoreButton = document.getElementById('load-more-economy');
            if (loadMoreButton) {
                if (articles.length === ARTICLES_PER_LOAD_DEFAULT) {
                    loadMoreButton.classList.remove('hidden');
                } else {
                    loadMoreButton.classList.add('hidden');
                }
            }
        });
    }

    if (technologyNewsContainer) {
        fetchNews(technologyNewsContainer, newsSearchTerms.technology, ARTICLES_PER_LOAD_DEFAULT, newsOffsets.technology).then(articles => {
            renderNews(articles, technologyNewsContainer);
            const loadMoreButton = document.getElementById('load-more-technology');
            if (loadMoreButton) {
                if (articles.length === ARTICLES_PER_LOAD_DEFAULT) {
                    loadMoreButton.classList.remove('hidden');
                } else {
                    loadMoreButton.classList.add('hidden');
                }
            }
        });
    }

    if (startupsNewsContainer) {
        fetchNews(startupsNewsContainer, newsSearchTerms.startups, ARTICLES_PER_LOAD_DEFAULT, newsOffsets.startups).then(articles => {
            renderNews(articles, startupsNewsContainer);
            const loadMoreButton = document.getElementById('load-more-startups');
            if (loadMoreButton) {
                if (articles.length === ARTICLES_PER_LOAD_DEFAULT) {
                    loadMoreButton.classList.remove('hidden');
                } else {
                    loadMoreButton.classList.add('hidden');
                }
            }
        });
    }

    if (predictionAnalysisContainer) {
        fetchNews(predictionAnalysisContainer, newsSearchTerms.prediction, ARTICLES_PER_LOAD_PREDICTION, newsOffsets.prediction).then(articles => {
            renderNews(articles, predictionAnalysisContainer, false);
            const loadMoreButton = document.getElementById('load-more-prediction');
            if (loadMoreButton) {
                if (articles.length === ARTICLES_PER_LOAD_PREDICTION) {
                    loadMoreButton.classList.remove('hidden');
                } else {
                    loadMoreButton.classList.add('hidden');
                }
            }
        });
    }

    document.getElementById('load-more-main')?.addEventListener('click', () => loadMoreNews(mainNewsContainer, 'main'));
    document.getElementById('load-more-economy')?.addEventListener('click', () => loadMoreNews(economyNewsContainer, 'economy'));
    document.getElementById('load-more-technology')?.addEventListener('click', () => loadMoreNews(technologyNewsContainer, 'technology'));
    document.getElementById('load-more-startups')?.addEventListener('click', () => loadMoreNews(startupsNewsContainer, 'startups'));
    document.getElementById('load-more-prediction')?.addEventListener('click', () => loadMoreNews(predictionAnalysisContainer, 'prediction'));

    const articleDetailContainer = document.getElementById('article-detail-container');
    const similarNewsContainer = document.getElementById('similar-news-container');

    if (articleDetailContainer && similarNewsContainer) {
        const urlParams = new URLSearchParams(window.location.search);
        const articleUuid = urlParams.get('uuid');

        if (articleUuid) {
            const storedArticle = sessionStorage.getItem('currentArticle');
            let mainArticle = null;
            if (storedArticle) {
                try {
                    mainArticle = JSON.parse(storedArticle);
                } catch (e) {
                    console.error("Error parsing stored article:", e);
                    mainArticle = null;
                }
            }

            if (mainArticle && mainArticle.uuid === articleUuid) {
                renderArticleDetail(mainArticle, articleDetailContainer);
                fetchSimilarNews(articleUuid).then(similarArticles => {
                    renderNews(similarArticles, similarNewsContainer, false);
                });
            } else {
                console.warn("Article not found in session storage or UUID mismatch for detail view.");
                articleDetailContainer.innerHTML = '<p class="text-red-600">Could not load article details from session. Please navigate from a news list.</p>';
                similarNewsContainer.innerHTML = '<p class="text-gray-600">Could not load similar news.</p>';
            }
        } else {
            if (articleDetailContainer) {
                articleDetailContainer.innerHTML = '<p class="text-red-600">No article specified.</p>';
            }
            if (similarNewsContainer) {
                similarNewsContainer.innerHTML = '';
            }
        }
    }
});

function renderArticleDetail(article, containerElement) {
    containerElement.innerHTML = '';

    const imageUrl = article.image_url && article.image_url.startsWith('http') ? article.image_url : 'https://placehold.co/600x400/e2e8f0/000?text=News+Image';
    const articleContent = article.description || article.snippet || 'No detailed content available.';

    const articleHtml = `
        <div class="bg-white p-6 rounded-lg shadow-sm">
            <img src="${imageUrl}" alt="Article Image" class="w-full h-auto object-cover rounded mb-6" onerror="this.onerror=null; this.src='https://placehold.co/600x400/e2e8f0/000?text=No+Image';">
            <h1 class="text-2xl font-bold text-gray-900 mb-4">${article.title}</h1>
            <p class="text-gray-600 text-sm mb-4">Published by ${article.source} on ${new Date(article.published_at).toLocaleDateString()}</p>
            <div class="text-gray-800 leading-relaxed mb-6">
                ${articleContent.replace(/\n/g, '<br>')}
            </div>
            ${article.url ? `<a href="${article.url}" target="_blank" rel="noopener noreferrer" class="text-blue-600 hover:underline">Read original article on ${article.source}</a>` : ''}
        </div>
    `;
    containerElement.innerHTML = articleHtml;
}



// -------------------------------------------------------------------------------------
const FMP_API_KEY_ = "T8HogSezq0WNy97WinOjjLMEOuiKjnu5";

const tickerSymbols = [
    'RELIANCE.NS', 'HINDUNILVR.NS', 'HDFCBANK.NS', 'BHARTIARTL.NS', 'MARUTI.NS', 'SBIN.NS',
    'WIPRO.NS', 'ICICIBANK.NS', 'AXISBANK.NS', 'KOTAKBANK.NS',
    'ITC.NS', 'LT.NS', 'SUNPHARMA.NS', 'ASIANPAINT.NS', 'BAJFINANCE.NS', 'NESTLEIND.NS',
    'ULTRACEMCO.NS', 'POWERGRID.NS', 'NTPC.NS', 'TITAN.NS', 'TECHM.NS', 'GRASIM.NS',
    'ADANIENT.NS', 'ADANIGREEN.NS', 'ADANIPORTS.NS', 'ONGC.NS', 'COALINDIA.NS', 'JSWSTEEL.NS',
    'HCLTECH.NS', 'BPCL.NS', 'IOC.NS', 'EICHERMOT.NS', 'HEROMOTOCO.NS', 'TATAMOTORS.NS'
];

const stockTickerContent = document.getElementById('stock-ticker-content');

async function fetchAndRenderStockTicker() {
    if (FMP_API_KEY_ === "") {
        stockTickerContent.innerHTML = '<div class="scroll-item text-red-600">API Key is empty. Cannot fetch stock data.</div>';
        return;
    }

    const symbolsString = tickerSymbols.join(',');
    const quoteApiUrl = `https://financialmodelingprep.com/api/v3/quote/${symbolsString}?apikey=${FMP_API_KEY_}`;

    try {
        stockTickerContent.innerHTML = '<div class="scroll-item text-gray-600">Fetching stock data...</div>';
        const response = await fetch(quoteApiUrl);

        if (!response.ok) {
            const errorText = await response.text();
            console.error(`HTTP error fetching stock data! Status: ${response.status}, Body: ${errorText}`);
            stockTickerContent.innerHTML = `<div class="scroll-item text-red-600">Error fetching data: ${response.status}. Check console.</div>`;
            return;
        }

        const data = await response.json();
        stockTickerContent.innerHTML = '';

        const itemsToDuplicate = [];
        let foundValidData = false;

        tickerSymbols.forEach(symbol => {
            const stockData = data.find(d => d.symbol === symbol);

            if (stockData && stockData.price !== undefined) {
                foundValidData = true;

                const price = parseFloat(stockData.price).toFixed(2);
                const change = parseFloat(stockData.change).toFixed(2);
                const changePercentage = parseFloat(stockData.changesPercentage).toFixed(2);

                let colorClass = 'text-gray-700';
                if (Math.sign(change) > 0) colorClass = 'text-green-600';
                else if (Math.sign(change) < 0) colorClass = 'text-red-600';

                const scrollItem = document.createElement('div');
                scrollItem.classList.add('scroll-item', 'text-sm');
                scrollItem.innerHTML = `
                    <span class="font-semibold">${symbol.replace('.NS', '')}:</span>
                    <span class="text-white-400">${price}</span>
                    <span class="${colorClass}">${change > 0 ? '+' : ''}${change} (${changePercentage}%)</span>
                `;
                itemsToDuplicate.push(scrollItem);
            } else {
                const scrollItem = document.createElement('div');
                scrollItem.classList.add('scroll-item', 'text-sm', 'text-yellow-600');
                scrollItem.textContent = `${symbol.replace('.NS', '')}: N/A`;
                itemsToDuplicate.push(scrollItem);
            }
        });

        if (!foundValidData) {
            stockTickerContent.innerHTML = '<div class="scroll-item text-red-600">No valid stock data received.</div>';
            return;
        }

        itemsToDuplicate.forEach(item => stockTickerContent.appendChild(item.cloneNode(true)));
        itemsToDuplicate.forEach(item => stockTickerContent.appendChild(item.cloneNode(true)));

        if (stockTickerContent.children.length > 0) {
            stockTickerContent.style.animation = 'scroll 30s linear infinite';
        } else {
            stockTickerContent.innerHTML = '<div class="scroll-item text-red-600">No stock data to display.</div>';
        }

    } catch (error) {
        console.error("Fetch Error fetching stock data:", error);
        stockTickerContent.innerHTML = '<div class="scroll-item text-red-600">Failed to fetch stock data. Check console for details.</div>';
    }
}


document.addEventListener('DOMContentLoaded', () => {
    fetchAndRenderStockTicker();
});

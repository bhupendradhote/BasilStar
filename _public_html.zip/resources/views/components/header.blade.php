		<!-- header-area start -->
		<header class="theme-main-menu theme-menu-five">
			<div class="container-fluid custom-container">
				<div class="main-header-area">
					<div class="row align-items-center justify-content-between">
						<div class="col-md-auto col-6">
							<div class="logo-area">
								<a href="index.html"><img class="logo-img" src="assets/img/logo/BasilLogo.png" alt="Header-logo"></a>
							</div>
						</div>
						<div class="col-md-auto d-flex align-items-center justify-content-end d-lg-inline-block d-none">
							<div class="main-menu d-none d-lg-block">
								<nav id="mobile-menu">
									<ul class="menu-list">
										<li>
											<a href="/">
												Home
											</a>
										</li>
											<li>
											<a href="/about">
												About
											</a>
										</li>
										<li>
											<a href="/about">
												About
											</a>
										</li>
										<li>
											<a href="/services">Service</a>
										</li>
										<li>
											<a href="/contact">Contact</a>
										</li>
	
									

									</ul>
								</nav>
							</div>
						</div>
						<div class="col-md-auto col-6">
							<div class="right-nav d-flex align-items-center justify-content-end">
								
								<div class="quote-btn d-lg-inline-block d-none">
						
									<a href="/contact" class="ht-btn bs-btn" data-bs-toggle="modal"
										data-bs-target="#loginModal">Sign Up to Dashboard</a>
								</div>
								<div class="search-area ms-1 d-none">
									<a class="search-input" href="/" data-bs-toggle="offcanvas"
										data-bs-target="#offcanvasTop" aria-controls="offcanvasTop">
										<i class="bi bi-search"></i>
									</a>
								</div>
								<div class="hamburger-menu ms-0 d-lg-none d-md-inline-flex">
									<div class="bar-wrap">
										<div class="bar-1"></div>
										<div class="bar-2"></div>
										<div class="bar-3"></div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- /.theme-main-menu -->
		</header>
		<!-- header-area end -->
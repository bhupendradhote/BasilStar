<!-- Sidebar -->
<aside id="sidebar" class="fixed md:static w-64 h-screen bg-white shadow-lg transform -translate-x-full md:translate-x-0 transition-all duration-200 ease-in-out z-50 sidebar-fixed">
    <div class="flex items-center justify-between p-4 border-b sidebar-header-toggle">
        <div class="flex items-center space-x-2">
            <i class="fas fa-chart-line text-blue-500 text-2xl"></i>
            <span id="sidebar-header-text" class="text-xl font-bold text-gray-800">FundFlow Pro</span>
        </div>
        <button class="md:hidden text-gray-500" onclick="toggleMobileSidebar()">
            <i class="fas fa-times"></i>
        </button>
    </div>
    
    <div class="p-4">
        <!-- User Profile -->
        <div class="flex items-center space-x-3 p-3 rounded-lg bg-gray-50 mb-4">
            <img src="https://ui-avatars.com/api/?name=Admin+User&background=3b82f6&color=fff" alt="User" class="w-10 h-10 rounded-full">
            <div id="sidebar-user-info">
                <p class="font-medium text-gray-800">Admin User</p>
                <p class="text-xs text-gray-500">Administrator</p>
            </div>
        </div>
        
        <!-- Navigation -->
        <nav class="space-y-1">
            <a href="<?php echo e(route('admin.dashboard')); ?>" class="sidebar-item flex items-center space-x-3 p-3 rounded-lg transition <?php echo e(request()->routeIs('admin.dashboard') ? 'active' : ''); ?>">
                <i class="fas fa-tachometer-alt text-gray-500 w-5"></i>
                <span>Dashboard</span>
            </a>
            
            <a href="" class="sidebar-item flex items-center space-x-3 p-3 rounded-lg transition <?php echo e(request()->routeIs('admin.portfolio') ? 'active' : ''); ?>">
                <i class="fas fa-chart-pie text-gray-500 w-5"></i>
                <span>Portfolio</span>
            </a>
            
            <a href="" class="sidebar-item flex items-center space-x-3 p-3 rounded-lg transition <?php echo e(request()->routeIs('admin.markets') ? 'active' : ''); ?>">
                <i class="fas fa-chart-line text-gray-500 w-5"></i>
                <span>Market Data</span>
            </a>
            
            <a href="" class="sidebar-item flex items-center space-x-3 p-3 rounded-lg transition <?php echo e(request()->routeIs('admin.transactions') ? 'active' : ''); ?>">
                <i class="fas fa-exchange-alt text-gray-500 w-5"></i>
                <span>Transactions</span>
            </a>
            
            <a href="" class="sidebar-item flex items-center space-x-3 p-3 rounded-lg transition <?php echo e(request()->routeIs('admin.clients') ? 'active' : ''); ?>">
                <i class="fas fa-users text-gray-500 w-5"></i>
                <span>Clients</span>
            </a>
            
            <a href="" class="sidebar-item flex items-center space-x-3 p-3 rounded-lg transition <?php echo e(request()->routeIs('admin.reports') ? 'active' : ''); ?>">
                <i class="fas fa-file-alt text-gray-500 w-5"></i>
                <span>Reports</span>
            </a>
            
            <div class="pt-4 mt-4 border-t">
                <p id="sidebar-settings-text" class="text-xs font-semibold text-gray-500 uppercase tracking-wider px-3 mb-2">Settings</p>
                
                <a href="" class="sidebar-item flex items-center space-x-3 p-3 rounded-lg transition <?php echo e(request()->routeIs('admin.settings') ? 'active' : ''); ?>">
                    <i class="fas fa-cog text-gray-500 w-5"></i>
                    <span>System Settings</span>
                </a>
                
                <a href="" class="sidebar-item flex items-center space-x-3 p-3 rounded-lg transition <?php echo e(request()->routeIs('admin.users') ? 'active' : ''); ?>">
                    <i class="fas fa-user-shield text-gray-500 w-5"></i>
                    <span>User Management</span>
                </a>
            </div>
        </nav>
    </div>
    
    <!-- Logout -->
    <div class="absolute bottom-0 left-0 right-0 p-4 border-t">
        <form method="POST" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit" class="w-full flex items-center space-x-3 p-3 rounded-lg text-red-500 hover:bg-red-50 transition">
                <i class="fas fa-sign-out-alt w-5"></i>
                <span>Logout</span>
            </button>
        </form>
    </div>
</aside>

<!-- Overlay for mobile -->
<div id="sidebar-overlay" class="fixed inset-0 bg-black bg-opacity-50 z-40 md:hidden hidden" onclick="toggleMobileSidebar()"></div>
<?php /**PATH /home/u756254243/domains/basilstar.com/public_html/resources/views/layouts/adminSidebar.blade.php ENDPATH**/ ?>
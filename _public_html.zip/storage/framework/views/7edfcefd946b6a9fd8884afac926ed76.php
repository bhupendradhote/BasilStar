<?php $__env->startSection('title', 'Market Prediction'); ?>
<?php $__env->startSection('content'); ?>


<div class="main_market_prediction">
    <div class="prediction-section">
        <div class="prediction-header">
            <h3 class="mb-2 fw-bold">Market Prediction</h3>
            <p class="mb-0 opacity-75">Accurate market forecasts powered by advanced analytics</p>
        </div>
        
        <div class="container py-4">
            <!-- Index Prediction Section -->
            <div class="row">
                <div class="col-12">
                    <h5 class="text-uppercase text-muted mb-3 fw-bold">Index Prediction</h5>
                </div>
                
                <div class="col-md-4 mb-3">
                    <a href="/marketPredictionDetails" class="text-decoration-none">
                        <div class="prediction-card">
                            <div class="prediction-card-body">
                                <h6 class="prediction-card-title">SENSEX Prediction</h6>
                                <div class="d-flex justify-content-end">
                                    <svg class="prediction-card-icon" width="20" height="20" viewBox="0 0 320 512" xmlns="http://www.w3.org/2000/svg">
                                        <path fill="currentColor" d="M278.6 233.4c12.5 12.5 12.5 32.8 0 45.3l-160 160c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L210.7 256 73.4 118.6c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0l160 160z"></path>
                                    </svg>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                
                <div class="col-md-4 mb-3">
                    <a href="/marketPredictionDetails" class="text-decoration-none">
                        <div class="prediction-card">
                            <div class="prediction-card-body">
                                <h6 class="prediction-card-title">NIFTY Prediction</h6>
                                <div class="d-flex justify-content-end">
                                    <svg class="prediction-card-icon" width="20" height="20" viewBox="0 0 320 512" xmlns="http://www.w3.org/2000/svg">
                                        <path fill="currentColor" d="M278.6 233.4c12.5 12.5 12.5 32.8 0 45.3l-160 160c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L210.7 256 73.4 118.6c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0l160 160z"></path>
                                    </svg>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                
                <div class="col-md-4 mb-3">
                    <a href="/marketPredictionDetails" class="text-decoration-none">
                        <div class="prediction-card">
                            <div class="prediction-card-body">
                                <h6 class="prediction-card-title">BANK NIFTY Prediction</h6>
                                <div class="d-flex justify-content-end">
                                    <svg class="prediction-card-icon" width="20" height="20" viewBox="0 0 320 512" xmlns="http://www.w3.org/2000/svg">
                                        <path fill="currentColor" d="M278.6 233.4c12.5 12.5 12.5 32.8 0 45.3l-160 160c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L210.7 256 73.4 118.6c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0l160 160z"></path>
                                    </svg>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                
                <div class="col-md-4 mb-3">
                    <a href="/marketPredictionDetails" class="text-decoration-none">
                        <div class="prediction-card">
                            <div class="prediction-card-body">
                                <h6 class="prediction-card-title">FINNIFTY Prediction</h6>
                                <div class="d-flex justify-content-end">
                                    <svg class="prediction-card-icon" width="20" height="20" viewBox="0 0 320 512" xmlns="http://www.w3.org/2000/svg">
                                        <path fill="currentColor" d="M278.6 233.4c12.5 12.5 12.5 32.8 0 45.3l-160 160c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L210.7 256 73.4 118.6c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0l160 160z"></path>
                                    </svg>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                
                <div class="col-md-4 mb-3">
                    <a href="/marketPredictionDetails" class="text-decoration-none">
                        <div class="prediction-card">
                            <div class="prediction-card-body">
                                <h6 class="prediction-card-title">MIDCPNIFTY Prediction</h6>
                                <div class="d-flex justify-content-end">
                                    <svg class="prediction-card-icon" width="20" height="20" viewBox="0 0 320 512" xmlns="http://www.w3.org/2000/svg">
                                        <path fill="currentColor" d="M278.6 233.4c12.5 12.5 12.5 32.8 0 45.3l-160 160c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L210.7 256 73.4 118.6c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0l160 160z"></path>
                                    </svg>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
            
            <hr class="section-divider">
            
            <!-- Index Future Prediction Section -->
            <div class="row mt-4">
                <div class="col-12">
                    <h5 class="text-uppercase text-muted mb-3 fw-bold">Index Future Prediction</h5>
                </div>
                
                <div class="col-md-4 mb-3">
                    <a href="/marketPredictionDetails" class="text-decoration-none">
                        <div class="prediction-card">
                            <div class="prediction-card-body">
                                <h6 class="prediction-card-title">NIFTY FUTURE Prediction</h6>
                                <div class="d-flex justify-content-end">
                                    <svg class="prediction-card-icon" width="20" height="20" viewBox="0 0 320 512" xmlns="http://www.w3.org/2000/svg">
                                        <path fill="currentColor" d="M278.6 233.4c12.5 12.5 12.5 32.8 0 45.3l-160 160c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L210.7 256 73.4 118.6c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0l160 160z"></path>
                                    </svg>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                
                <div class="col-md-4 mb-3">
                    <a href="/marketPredictionDetails" class="text-decoration-none">
                        <div class="prediction-card">
                            <div class="prediction-card-body">
                                <h6 class="prediction-card-title">BANK NIFTY FUTURE Prediction</h6>
                                <div class="d-flex justify-content-end">
                                    <svg class="prediction-card-icon" width="20" height="20" viewBox="0 0 320 512" xmlns="http://www.w3.org/2000/svg">
                                        <path fill="currentColor" d="M278.6 233.4c12.5 12.5 12.5 32.8 0 45.3l-160 160c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L210.7 256 73.4 118.6c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0l160 160z"></path>
                                    </svg>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                
                <div class="col-md-4 mb-3">
                    <a href="/marketPredictionDetails" class="text-decoration-none">
                        <div class="prediction-card">
                            <div class="prediction-card-body">
                                <h6 class="prediction-card-title">FINNIFTY FUTURE Prediction</h6>
                                <div class="d-flex justify-content-end">
                                    <svg class="prediction-card-icon" width="20" height="20" viewBox="0 0 320 512" xmlns="http://www.w3.org/2000/svg">
                                        <path fill="currentColor" d="M278.6 233.4c12.5 12.5 12.5 32.8 0 45.3l-160 160c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L210.7 256 73.4 118.6c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0l160 160z"></path>
                                    </svg>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                
                <div class="col-md-4 mb-3">
                    <a href="/marketPredictionDetails" class="text-decoration-none">
                        <div class="prediction-card">
                            <div class="prediction-card-body">
                                <h6 class="prediction-card-title">MIDCPNIFTY FUTURE Prediction</h6>
                                <div class="d-flex justify-content-end">
                                    <svg class="prediction-card-icon" width="20" height="20" viewBox="0 0 320 512" xmlns="http://www.w3.org/2000/svg">
                                        <path fill="currentColor" d="M278.6 233.4c12.5 12.5 12.5 32.8 0 45.3l-160 160c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L210.7 256 73.4 118.6c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0l160 160z"></path>
                                    </svg>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
            
            <!-- SEBI Badge -->

        </div>
    </div>
</div>

<script>
    // Add animation on page load
    document.addEventListener('DOMContentLoaded', function() {
        const cards = document.querySelectorAll('.prediction-card');
        cards.forEach((card, index) => {
            card.style.opacity = '0';
            card.style.transform = 'translateY(20px)';
            card.style.transition = `all 0.5s ease ${index * 0.1}s`;
            
            setTimeout(() => {
                card.style.opacity = '1';
                card.style.transform = 'translateY(0)';
            }, 100);
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboardLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/u756254243/domains/basilstar.com/public_html/resources/views////BasilTrade/marketPrediction.blade.php ENDPATH**/ ?>
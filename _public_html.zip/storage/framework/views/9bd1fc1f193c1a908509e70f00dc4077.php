 

    <?php $__env->startSection('title', 'liveChart'); ?>

    <?php $__env->startSection('content'); ?>
<style>
    .select2-container--default .select2-selection--single .select2-selection__rendered {
    line-height: 13px !important;
}
</style>
		<script>
        document.addEventListener('DOMContentLoaded', function () {
            if (localStorage.getItem('showAlert') === 'true') {
                Swal.fire({
                    title: 'Login Successful!',
                    text: 'Welcome to the live chart.',
                    icon: 'success',
                    confirmButtonText: 'OK',
                    confirmButtonColor: '#007bff',
                }).then(() => {
                    localStorage.removeItem('showAlert'); // Remove the flag after showing the alert
                });
            }
        });
    </script>
		<script>
			document.addEventListener('DOMContentLoaded', () => {
			  // Hamburger menu toggle
			  const hamburger = document.getElementById('hamburger-menu');
			  const navDropdown = document.getElementById('nav-dropdown');
			
			  hamburger.addEventListener('click', () => {
			    navDropdown.classList.toggle('active');
			  });
			
			  // Close dropdown when clicking outside
			  document.addEventListener('click', (event) => {
			    if (!navDropdown.contains(event.target) && !hamburger.contains(event.target)) {
			      navDropdown.classList.remove('active');
			    }
			  });
			
			  // Tab functionality
			  const tabButtons = document.querySelectorAll('.tab-button');
			  const tabContents = document.querySelectorAll('.tab-content');
			
			  tabButtons.forEach(button => {
			    button.addEventListener('click', () => {
			      const targetTab = button.dataset.tab;
			
			      // Remove active class from all buttons and contents
			      tabButtons.forEach(btn => btn.classList.remove('active'));
			      tabContents.forEach(content => content.classList.remove('active'));
			
			      // Add active class to the clicked button and target content
			      button.classList.add('active');
			      document.getElementById(targetTab).classList.add('active');
			    });
			  });
			
			  // Activate the first tab by default
			  if (tabButtons.length > 0) {
			    tabButtons[0].click();
			  }
			});
		</script>
	<body class="dark-theme">
		<div class="app-container">

			<main class="main-content">
				<nav class="tab-nav">
					<button class="tab-button active" data-tab="overview-tab">Overview</button>
					<button class="tab-button" data-tab="chart-tab">Fundamental Analysis</button>
					<button class="tab-button" data-tab="technical-analysis-tab">Technical Analysis</button>
					<button class="tab-button" data-tab="key-metrics-tab">Key Metrics</button>
					<button class="tab-button" data-tab="share-holding-tab">Share Holding</button>
					<button class="tab-button" data-tab="quarterly-results-tab">Quarterly Results</button>
					<button class="tab-button" data-tab="pnl-tab">P&L</button>
					<button class="tab-button" data-tab="cash-flow-tab">Cash Flow</button>
					<button class="tab-button" data-tab="corporate-actions-tab">Corporate Actions</button>
					<button class="tab-button" data-tab="company-details-tab">Company Details</button>
				</nav>
				<div id="overview-tab" class="tab-content active">
					<section class="chart-section">
						<div class="chart-container">
							<div class="control-group" style="margin-bottom: 1.5rem;">
								<select id="stockSelector"></select>
								<div class="timeframe-selector" id="timeframeSelector">
									<button data-range="1d">1D</button>
									<button data-range="1w">1W</button>
									<button data-range="1m">1M</button>
									<button data-range="3m">3M</button>
									<button data-range="1y">1Y</button>
									<button data-range="3y">3Y</button>
									<button data-range="5y">5Y</button>
									<button data-range="max">MAX</button>
								</div>
							</div>
							<div class="chart-header">
								<div class="chart-title">
									<h2 id="chartTitle">Price Chart</h2>
								</div>
								<div class="chart-actions">
									<button>
									<i class="fas fa-expand"></i>
									</button>
								</div>
							</div>
							<canvas id="stockChart"></canvas>
						</div>
					</section>
					<div class="data-grid">
						<div class="data-card">
							<div class="card-header">
								<div class="card-title">Current Market Data</div>
							</div>
							<div class="data-row">
								<span class="data-label">Open:</span>
								<span class="data-value" id="latestOpen">N/A</span>
							</div>
							<div class="data-row">
								<span class="data-label">High:</span>
								<span class="data-value" id="latestHigh">N/A</span>
							</div>
							<div class="data-row">
								<span class="data-label">Low:</span>
								<span class="data-value" id="latestLow">N/A</span>
							</div>
							<div class="data-row">
								<span class="data-label">Close:</span>
								<span class="data-value" id="latestClose">N/A</span>
							</div>
							<div class="data-row">
								<span class="data-label">Percent Change:</span>
								<span class="data-value" id="percentChange">N/A</span>
							</div>
							<div class="data-row">
								<span class="data-label">Change:</span>
								<span class="data-value" id="priceChange">N/A</span>
							</div>
							<div class="data-row">
								<span class="data-label">Volume:</span>
								<span class="data-value" id="latestVolume">N/A</span>
							</div>
						</div>
						<div class="data-card">
							<div class="card-header">
								<div class="card-title">Current Market Status</div>
							</div>
							<div class="data-row">
								<span class="data-label">Market Status:</span>
								<span class="data-value" id="marketStatus">N/A</span>
							</div>
							<div class="data-row">
								<span class="data-label">52-Week Low:</span>
								<span class="data-value" id="fiftyTwoWeekLow">N/A</span>
							</div>
							<div class="data-row">
								<span class="data-label">52-Week High:</span>
								<span class="data-value" id="fiftyTwoWeekHigh">N/A</span>
							</div>
							<div class="data-row">
								<span class="data-label">52-Week Range:</span>
								<span class="data-value" id="fiftyTwoWeekRange">N/A</span>
							</div>
							<div class="data-row">
								<span class="data-label">Extended Price:</span>
								<span class="data-value" id="extendedPrice">N/A</span>
							</div>
							<div class="data-row">
								<span class="data-label">Extended Change:</span>
								<span class="data-value" id="extendedChange">N/A</span>
							</div>
							<div class="data-row">
								<span class="data-label">Extended Percent Change:</span>
								<span class="data-value" id="extendedPercentChange">N/A</span>
							</div>
						</div>
					</div>
					<div class="data-grid" style="margin-bottom: 2rem;">
						<div class="data-card">
							<div class="card-header">
								<div class="card-title">Market Sentiment</div>
								<div class="card-actions">
									<button>
									<i class="fas fa-ellipsis-h"></i>
									</button>
								</div>
							</div>
							<div class="sentiment-meter">
								<div class="sentiment-progress" style="width: 65%"></div>
							</div>
							<div class="sentiment-data">
								<div class="santi-data-row">
									<span class="data-label">1D:</span>
									<span class="data-value" id="sentiment1d"></span>
								</div>
								<div class="santi-data-row">
									<span class="data-label">1W:</span>
									<span class="data-value" id="sentiment1w"></span>
								</div>
								<div class="santi-data-row">
									<span class="data-label">1M:</span>
									<span class="data-value" id="sentiment1m"></span>
								</div>
								<div class="santi-data-row">
									<span class="data-label">3M:</span>
									<span class="data-value" id="sentiment3m"></span>
								</div>
							</div>
						</div>
					</div>
					<div class="data-card" style="margin-bottom: 2rem;">
						<div class="card-header">
							<div class="card-title">Historical Data (Past 24 Days)</div>
							<div class="card-actions">
								<button>
								<i class="fas fa-ellipsis-h"></i>
								</button>
							</div>
						</div>
						<div class="historical-grid" id="pastCardContainer"></div>
					</div>
					<div class="data-grid">
						<div class="data-card">
							<div class="card-header">
								<div class="card-title">Returns Analysis</div>
								<div class="card-actions">
									<button>
									<i class="fas fa-ellipsis-h"></i>
									</button>
								</div>
							</div>
							<div class="data-row">
								<span class="data-label">Daily:</span>
								<span class="data-value" id="descDaily"></span>
							</div>
							<div class="data-row">
								<span class="data-label">Weekly:</span>
								<span class="data-value" id="descWeekly"></span>
							</div>
							<div class="data-row">
								<span class="data-label">Monthly:</span>
								<span class="data-value" id="descMonthly"></span>
							</div>
							<div class="data-row">
								<span class="data-label">Yearly:</span>
								<span class="data-value" id="descYearly"></span>
							</div>
						</div>
					</div>
				</div>
				<div id="chart-tab" class="tab-content">
					<div class="chart-section-fl">
						<div class="graph-container">
							<h2>Combined Chart (Sales, Gross Profit, Net Income)</h2>
							<canvas id="combinedChart"></canvas>
						</div>
						<div class="graph-container">
							<h2>Operating Income and EBITDA</h2>
							<canvas id="operatingIncomeChart"></canvas>
						</div>
					</div>
					<div class="table-container">
						<h2>Income Statement Table</h2>
						<div class="table-wrapper">
							<!-- Time Column -->
							<div class="metrics-table">
								<table id="incomeStatementTable" border="1" cellpadding="10" cellspacing="0">
									<thead id="incomeStatementTableHead">
										<!-- Dynamic headers will go here -->
									</thead>
									<tbody id="incomeStatementTableBody">
										<!-- Rows will be dynamically added here -->
									</tbody>
								</table>
							</div>
						</div>
					</div>
					<div>
						<h2>Balance Sheet Analysis</h2>
						<div class="balance-sheet-section">
							<div class="balance-chart-section">
								<canvas id="balanceSheetChart"></canvas>
							</div>
							<div class="table-container">
								<div class="table-wrapper">
									<table id="balanceSheetTable" border="1" cellpadding="10" cellspacing="0">
										<thead id="balanceSheetHeaderRow">
											<!-- Dates will be dynamically added here as table headers -->
										</thead>
										<tbody id="balanceSheetTableBody">
											<!-- Financial data rows will be dynamically added here -->
										</tbody>
									</table>
								</div>
							</div>
						</div>
					</div>
					<div class="data-card">
						<div class="card-header">
							<div class="card-title">Earnings Data</div>
						</div>
						<table class="data-table">
							<thead id="earningsTableHead"></thead>
							<tbody id="earningsTableBody"></tbody>
						</table>
					</div>
					
				</div>
				<div id="technical-analysis-tab" class="tab-content">
					<div class="data-card">
						<div class="card-header">
							<div class="card-title">Moving Averages</div>
							<div class="card-actions">
								<button>
								<i class="fas fa-ellipsis-h"></i>
								</button>
							</div>
						</div>
						<div class="data-row">
							<span class="data-label">20-Day:</span>
							<span class="data-value" id="ma20Status"></span>
						</div>
						<div class="data-row">
							<span class="data-label">50-Day:</span>
							<span class="data-value" id="ma50Status"></span>
						</div>
						<div class="data-row">
							<span class="data-label">100-Day:</span>
							<span class="data-value" id="ma100Status"></span>
						</div>
						<div class="data-row">
							<span class="data-label">200-Day:</span>
							<span class="data-value" id="ma200Status"></span>
						</div>
					</div>
					<div class="momentum-container">
						<div id="momentumSummary" style="font-weight: bold; margin-bottom: 10px;"></div>
						<div id="momentumTable" class="momentum-table"></div>
						<div>
							<h3 id="trendSummary" style="margin-top: 20px;">Trend Oscillators (Buy : 0)(Sell: 0)(Neutral: 0)</h3>
							<table border="1" cellpadding="10" cellspacing="0">
								<thead>
									<tr>
										<th>Name</th>
										<th>Value</th>
										<th>Action</th>
									</tr>
								</thead>
								<tbody>
									<tr id="trendMACD">
										<td>MACD(12,26)</td>
										<td class="trend-value">-</td>
										<td class="trend-action">-</td>
									</tr>
									<tr id="trendADX">
										<td>ADX(14)</td>
										<td class="trend-value">-</td>
										<td class="trend-action">-</td>
									</tr>
								</tbody>
							</table>
						</div>
					</div>
					<div id="marketIndicators">
						<h3> Market Analysis</h3>
						<table>
							<tr>
								<th>Indicator</th>
								<th>Value</th>
							</tr>
							<tr>
								<td>Bollinger Bands (20)</td>
								<td id="bollingerValue"></td>
							</tr>
							<tr>
								<td>ATR (14)</td>
								<td id="atrValue"></td>
							</tr>
							<tr>
								<td>On-Balance Volume (OBV)</td>
								<td id="obvValue"></td>
							</tr>
							<tr>
								<td>Latest Candle</td>
								<td id="candleValue"></td>
							</tr>
						</table>
					</div>
					<div id="marketIndicators">
						<h3>Pivot Points</h3>
						<div id="pivotTableContainer"></div>
					</div>
				</div>
				<div id="key-metrics-tab" class="tab-content">
					<div id="statisticsDataContainer" style="margin-top: 0;">
						<h2 class="section-title">Stock Statistics</h2>
						<div class="data-card" style="margin-bottom: 1.5rem;">
							<div class="card-header">
								<div class="card-title">
									<i class="fas fa-chart-line icon-blue"></i> Valuations Metrics
								</div>
							</div>
							<div class="data-grid">
								<div class="data-row">
									<span class="data-label"><i class="fas fa-chart-line icon-blue"></i> Market Capitalization:</span>
									<span class="data-value" id="marketCapitalization">-</span>
								</div>
								<div class="data-row">
									<span class="data-label"><i class="fas fa-building icon-green"></i> Enterprise Value:</span>
									<span class="data-value" id="enterpriseValue">-</span>
								</div>
								<div class="data-row">
									<span class="data-label"><i class="fas fa-percentage icon-orange"></i> Trailing PE:</span>
									<span class="data-value" id="trailingPE">-</span>
								</div>
								<div class="data-row">
									<span class="data-label"><i class="fas fa-percentage icon-orange"></i> Forward PE:</span>
									<span class="data-value" id="forwardPE">-</span>
								</div>
								<div class="data-row">
									<span class="data-label"><i class="fas fa-balance-scale icon-purple"></i> PEG Ratio:</span>
									<span class="data-value" id="pegRatio">-</span>
								</div>
								<div class="data-row">
									<span class="data-label"><i class="fas fa-chart-bar icon-blue"></i> Price to Sales (TTM):</span>
									<span class="data-value" id="priceToSalesTTM">-</span>
								</div>
								<div class="data-row">
									<span class="data-label"><i class="fas fa-book icon-green"></i> Price to Book (MRQ):</span>
									<span class="data-value" id="priceToBookMRQ">-</span>
								</div>
								<div class="data-row">
									<span class="data-label"><i class="fas fa-receipt icon-purple"></i> Enterprise to Revenue:</span>
									<span class="data-value" id="enterpriseToRevenue">-</span>
								</div>
								<div class="data-row">
									<span class="data-label"><i class="fas fa-chart-pie icon-orange"></i> Enterprise to EBITDA:</span>
									<span class="data-value" id="enterpriseToEBITDA">-</span>
								</div>
							</div>
						</div>
						<div class="data-card" style="margin-bottom: 1.5rem;">
							<div class="card-header">
								<div class="card-title">
									<i class="fas fa-coins icon-yellow"></i> Financials
								</div>
							</div>
							<div class="data-grid">
								<div class="data-row">
									<span class="data-label"><i class="fas fa-calendar-alt icon-blue"></i> Fiscal Year Ends:</span>
									<span class="data-value" id="fiscalYearEnds">-</span>
								</div>
								<div class="data-row">
									<span class="data-label"><i class="fas fa-calendar-check icon-green"></i> Most Recent Quarter:</span>
									<span class="data-value" id="mostRecentQuarter">-</span>
								</div>
								<div class="data-row">
									<span class="data-label"><i class="fas fa-percentage icon-orange"></i> Gross Margin:</span>
									<span class="data-value" id="grossMargin">-</span>
								</div>
								<div class="data-row">
									<span class="data-label"><i class="fas fa-percentage icon-orange"></i> Profit Margin:</span>
									<span class="data-value" id="profitMargin">-</span>
								</div>
								<div class="data-row">
									<span class="data-label"><i class="fas fa-chart-line icon-blue"></i> Operating Margin:</span>
									<span class="data-value" id="operatingMargin">-</span>
								</div>
								<div class="data-row">
									<span class="data-label"><i class="fas fa-chart-area icon-purple"></i> Return on Assets (TTM):</span>
									<span class="data-value" id="returnOnAssetsTTM">-</span>
								</div>
								<div class="data-row">
									<span class="data-label"><i class="fas fa-chart-area icon-purple"></i> Return on Equity (TTM):</span>
									<span class="data-value" id="returnOnEquityTTM">-</span>
								</div>
							</div>
						</div>
						<div class="data-card" style="margin-bottom: 1.5rem;">
							<div class="card-header">
								<div class="card-title">
									<i class="fas fa-file-invoice-dollar icon-green"></i> Income Statement (TTM)
								</div>
							</div>
							<div class="data-grid">
								<div class="data-row">
									<span class="data-label"><i class="fas fa-dollar-sign icon-yellow"></i> Revenue:</span>
									<span class="data-value" id="revenueTTM_IS">-</span>
								</div>
								<div class="data-row">
									<span class="data-label"><i class="fas fa-chart-bar icon-blue"></i> Revenue per Share:</span>
									<span class="data-value" id="revenuePerShareTTM">-</span>
								</div>
								<div class="data-row">
									<span class="data-label"><i class="fas fa-chart-line icon-orange"></i> Quarterly Revenue Growth:</span>
									<span class="data-value" id="quarterlyRevenueGrowth">-</span>
								</div>
								<div class="data-row">
									<span class="data-label"><i class="fas fa-dollar-sign icon-yellow"></i> Gross Profit:</span>
									<span class="data-value" id="grossProfitTTM">-</span>
								</div>
								<div class="data-row">
									<span class="data-label"><i class="fas fa-chart-pie icon-purple"></i> EBITDA:</span>
									<span class="data-value" id="ebitda">-</span>
								</div>
								<div class="data-row">
									<span class="data-label"><i class="fas fa-dollar-sign icon-yellow"></i> Net Income to Common:</span>
									<span class="data-value" id="netIncomeToCommonTTM">-</span>
								</div>
								<div class="data-row">
									<span class="data-label"><i class="fas fa-percentage icon-orange"></i> Diluted EPS:</span>
									<span class="data-value" id="dilutedEPSTTM">-</span>
								</div>
								<div class="data-row">
									<span class="data-label"><i class="fas fa-chart-line icon-blue"></i> Quarterly Earnings Growth (YoY):</span>
									<span class="data-value" id="quarterlyEarningsGrowthYOY">-</span>
								</div>
							</div>
						</div>
						<div class="data-card" style="margin-bottom: 1.5rem;">
							<div class="card-header">
								<div class="card-title">
									<i class="fas fa-balance-scale-left icon-blue"></i> Balance Sheet (MRQ)
								</div>
							</div>
							<div class="data-grid">
								<div class="data-row">
									<span class="data-label"><i class="fas fa-dollar-sign icon-yellow"></i> Revenue (TTM - for comparison):</span>
									<span class="data-value" id="revenueTTM_BS">-</span>
								</div>
								<div class="data-row">
									<span class="data-label"><i class="fas fa-cash-register icon-green"></i> Total Cash:</span>
									<span class="data-value" id="totalCashMRQ">-</span>
								</div>
								<div class="data-row">
									<span class="data-label"><i class="fas fa-money-bill-alt icon-orange"></i> Total Cash per Share:</span>
									<span class="data-value" id="totalCashPerShareMRQ">-</span>
								</div>
								<div class="data-row">
									<span class="data-label"><i class="fas fa-hand-holding-usd icon-purple"></i> Total Debt:</span>
									<span class="data-value" id="totalDebtMRQ">-</span>
								</div>
								<div class="data-row">
									<span class="data-label"><i class="fas fa-percentage icon-orange"></i> Total Debt to Equity:</span>
									<span class="data-value" id="totalDebtToEquityMRQ">-</span>
								</div>
								<div class="data-row">
									<span class="data-label"><i class="fas fa-chart-area icon-blue"></i> Current Ratio:</span>
									<span class="data-value" id="currentRatioMRQ">-</span>
								</div>
								<div class="data-row">
									<span class="data-label"><i class="fas fa-book-open icon-green"></i> Book Value per Share:</span>
									<span class="data-value" id="bookValuePerShareMRQ">-</span>
								</div>
							</div>
						</div>
						<div class="data-card" style="margin-bottom: 1.5rem;">
							<div class="card-header">
								<div class="card-title">
									<i class="fas fa-cash-register icon-green"></i> Cash Flow (TTM)
								</div>
							</div>
							<div class="data-grid">
								<div class="data-row">
									<span class="data-label"><i class="fas fa-exchange-alt icon-purple"></i> Operating Cash Flow:</span>
									<span class="data-value" id="operatingCashFlowTTM">-</span>
								</div>
								<div class="data-row">
									<span class="data-label"><i class="fas fa-dollar-sign icon-yellow"></i> Levered Free Cash Flow:</span>
									<span class="data-value" id="leveredFreeCashFlowTTM">-</span>
								</div>
							</div>
						</div>
						<div class="data-card" style="margin-bottom: 1.5rem;">
							<div class="card-header">
								<div class="card-title">
									<i class="fas fa-chart-bar icon-blue"></i> Share & Trading Data
								</div>
							</div>
							<div class="data-grid">
								<div class="data-row">
									<span class="data-label"><i class="fas fa-users icon-green"></i> Shares Outstanding:</span>
									<span class="data-value" id="sharesOutstanding">-</span>
								</div>
								<div class="data-row">
									<span class="data-label"><i class="fas fa-user-alt icon-orange"></i> Float Shares:</span>
									<span class="data-value" id="floatShares">-</span>
								</div>
								<div class="data-row">
									<span class="data-label"><i class="fas fa-chart-area icon-purple"></i> Avg 10-Day Volume:</span>
									<span class="data-value" id="avg10Volume">-</span>
								</div>
								<div class="data-row">
									<span class="data-label"><i class="fas fa-chart-area icon-purple"></i> Avg 90-Day Volume:</span>
									<span class="data-value" id="avg90Volume">-</span>
								</div>
								<div class="data-row">
									<span class="data-label"><i class="fas fa-chart-line icon-blue"></i> Shares Short:</span>
									<span class="data-value" id="sharesShort">-</span>
								</div>
								<div class="data-row">
									<span class="data-label"><i class="fas fa-chart-bar icon-orange"></i> Short Ratio:</span>
									<span class="data-value" id="shortRatio">-</span>
								</div>
								<div class="data-row">
									<span class="data-label"><i class="fas fa-percentage icon-green"></i> Short % of Shares Outstanding:</span>
									<span class="data-value" id="shortPercentOfSharesOutstanding">-</span>
								</div>
								<div class="data-row">
									<span class="data-label"><i class="fas fa-user-secret icon-purple"></i> % Held by Insiders:</span>
									<span class="data-value" id="percentHeldByInsiders">-</span>
								</div>
								<div class="data-row">
									<span class="data-label"><i class="fas fa-building icon-blue"></i> % Held by Institutions:</span>
									<span class="data-value" id="percentHeldByInstitutions">-</span>
								</div>
							</div>
						</div>
						<div class="data-card" style="margin-bottom: 1.5rem;">
							<div class="card-header">
								<div class="card-title">
									<i class="fas fa-chart-line icon-blue"></i> Price Performance & Volatility
								</div>
							</div>
							<div class="data-grid">
								<div class="data-row">
									<span class="data-label"><i class="fas fa-arrow-down icon-green"></i> 52 Week Low:</span>
									<span class="data-value" id="fiftyTwoWeekLow">-</span>
								</div>
								<div class="data-row">
									<span class="data-label"><i class="fas fa-arrow-up icon-orange"></i> 52 Week High:</span>
									<span class="data-value" id="fiftyTwoWeekHigh">-</span>
								</div>
								<div class="data-row">
									<span class="data-label"><i class="fas fa-chart-line icon-blue"></i> 52 Week Change:</span>
									<span class="data-value" id="fiftyTwoWeekChange">-</span>
								</div>
								<div class="data-row">
									<span class="data-label"><i class="fas fa-chart-bar icon-purple"></i> Beta:</span>
									<span class="data-value" id="beta">-</span>
								</div>
								<div class="data-row">
									<span class="data-label"><i class="fas fa-chart-area icon-green"></i> 50-Day Moving Average:</span>
									<span class="data-value" id="day50MA">-</span>
								</div>
								<div class="data-row">
									<span class="data-label"><i class="fas fa-chart-area icon-orange"></i> 200-Day Moving Average:</span>
									<span class="data-value" id="day200MA">-</span>
								</div>
							</div>
						</div>
						<div class="data-card">
							<div class="card-header">
								<div class="card-title">
									<i class="fas fa-gift icon-purple"></i> Dividends & Splits
								</div>
							</div>
							<div class="data-grid">
								<div class="data-row">
									<span class="data-label"><i class="fas fa-hand-holding-usd icon-blue"></i> Forward Annual Dividend Rate:</span>
									<span class="data-value" id="forwardAnnualDividendRate">-</span>
								</div>
								<div class="data-row">
									<span class="data-label"><i class="fas fa-percentage icon-green"></i> Forward Annual Dividend Yield:</span>
									<span class="data-value" id="forwardAnnualDividendYield">-</span>
								</div>
								<div class="data-row">
									<span class="data-label"><i class="fas fa-hand-holding-usd icon-orange"></i> Trailing Annual Dividend Rate:</span>
									<span class="data-value" id="trailingAnnualDividendRate">-</span>
								</div>
								<div class="data-row">
									<span class="data-label"><i class="fas fa-percentage icon-purple"></i> Trailing Annual Dividend Yield:</span>
									<span class="data-value" id="trailingAnnualDividendYield">-</span>
								</div>
								<div class="data-row">
									<span class="data-label"><i class="fas fa-chart-line icon-blue"></i> 5 Year Average Dividend Yield:</span>
									<span class="data-value" id="fiveYearAverageDividendYield">-</span>
								</div>
								<div class="data-row">
									<span class="data-label"><i class="fas fa-percentage icon-green"></i> Payout Ratio:</span>
									<span class="data-value" id="payoutRatio">-</span>
								</div>
								<div class="data-row">
									<span class="data-label"><i class="fas fa-calendar-check icon-orange"></i> Dividend Frequency:</span>
									<span class="data-value" id="dividendFrequency">-</span>
								</div>
								<div class="data-row">
									<span class="data-label"><i class="fas fa-calendar-alt icon-purple"></i> Dividend Date:</span>
									<span class="data-value" id="dividendDate">-</span>
								</div>
								<div class="data-row">
									<span class="data-label"><i class="fas fa-calendar-times icon-blue"></i> Ex-Dividend Date:</span>
									<span class="data-value" id="exDividendDate">-</span>
								</div>
								<div class="data-row">
									<span class="data-label"><i class="fas fa-cut icon-green"></i> Last Split Factor:</span>
									<span class="data-value" id="lastSplitFactor">-</span>
								</div>
								<div class="data-row">
									<span class="data-label"><i class="fas fa-calendar-alt icon-orange"></i> Last Split Date:</span>
									<span class="data-value" id="lastSplitDate">-</span>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div id="share-holding-tab" class="tab-content">
					<div class="data-card">
						<div class="card-header">
							<div class="card-title">Share Holding Data</div>
						</div>
						<div class="data-card">
							<div class="card-header">
								<div class="card-title">Institutional Holders</div>
							</div>
							<canvas id="institutionalHoldersChart" style="max-height: 400px;"></canvas>
							<table class="data-table">
								<thead id="institutionalHoldersTableHead"></thead>
								<tbody id="institutionalHoldersTableBody"></tbody>
							</table>
						</div>
					</div>
				</div>
				<div id="quarterly-results-tab" class="tab-content">
					<div class="data-card">
						<div class="card-header">
							<div class="card-title">Quarterly Results</div>
						</div>
						<p>Quarterly results data will be displayed here.</p>
					</div>
				</div>
				<div id="pnl-tab" class="tab-content">
					<div class="data-card">
						<div class="card-header">
							<div class="card-title">Profit and Loss (P&L)</div>
						</div>
						<p>Profit and Loss data will be displayed here.</p>
					</div>
				</div>
				<div id="cash-flow-tab" class="tab-content">
					<div class="chart-section">
						<h2>Cash Flow Chart</h2>
						<canvas id="cashFlowChart"></canvas>
					</div>
					<div class="chart-section">
						<h2>Free Cash Flow vs Net Income</h2>
						<canvas id="freeCashFlowChart"></canvas>
					</div>
					<div class="table-container">
						<h2>Cash Flow Table</h2>
						<table id="cashFlowTable" border="1" cellpadding="10" cellspacing="0">
							<thead id="cashFlowTableHead">
								<!-- Dynamic headers will go here -->
							</thead>
							<tbody id="cashFlowTableBody">
								<!-- Rows will be dynamically added here -->
							</tbody>
						</table>
					</div>
				</div>
				<div id="corporate-actions-tab" class="tab-content">
					<div id="fundamentalDataContainer" style="margin-top: 0;">
						<h3>Fundamental Data (Dividends Calendar)</h3>
						<table id="fundamentalDataTable" border="1" cellpadding="10" cellspacing="0">
							<thead>
								<tr>
									<th>Ex-Date</th>
									<th>Amount</th>
								</tr>
							</thead>
							<tbody>
							</tbody>
						</table>
					</div>
					<div id="fetchFundamentalSplitssData" style="margin-top: 20px;">
						<h3>Splits Data (Splits Calendar)</h3>
						<table id="splitsDataTable" border="1" cellpadding="10" cellspacing="0">
							<thead>
								<tr>
									<th>Description</th>
									<th>Ratio</th>
									<th>From Factor</th>
									<th>To Factor</th>
									<th>Date</th>
								</tr>
							</thead>
							<tbody>
							</tbody>
						</table>
					</div>
				</div>
				<div id="company-details-tab" class="tab-content">
					<div id="companyProfileContainer" class="profile-container">
						<!-- Company profile, logo, and executives will be dynamically added here -->
					</div>
				</div>
			</main>
		</div>
		<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

	</body>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboardLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/u756254243/domains/basilstar.com/public_html/resources/views////BasilTrade/TradingDashboard.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Services'); ?>

<?php $__env->startSection('content'); ?>
	<div class="main-page-wrapper">



<!-- preloader start -->
<div id="preloader">
			<div id="ctn-preloader" class="ctn-preloader">
				<div class="txt-loading">
					<span data-text-preloader="B" class="letters-loading">
						B
					</span>
					<span data-text-preloader="a" class="letters-loading">
						a
					</span>
					<span data-text-preloader="s" class="letters-loading">
						s
					</span>
					<span data-text-preloader="i" class="letters-loading">
						i
					</span>
					<span data-text-preloader="l" class="letters-loading">
						l
					</span>
					<span data-text-preloader="S" class="letters-loading">
						S
					</span>
					<span data-text-preloader="t" class="letters-loading">
						t
					</span>
					<span data-text-preloader="a" class="letters-loading">
						a
					</span>
					<span data-text-preloader="r" class="letters-loading">
						r
					</span>
				</div>
			</div>
		</div>
		<!-- preloader end  -->


		<!-- offcanvas start  -->
		<div class="offcanvas offcanvas-top theme-bg" tabindex="-1" id="offcanvasTop">
			<div class="offcanvas-header">
				<a data-bs-dismiss="offcanvas" aria-label="Close">
					<i class="fas fa-times search-close" id="search-close"></i>
				</a>
			</div>
			<div class="offcanvas-body">
				<!-- Fullscreen search -->
				<div class="search-wrap">
					<form method="get">
						<input type="search" class="main-search-input" placeholder="Search Your Keyword...">
					</form>
				</div>
				<!-- end fullscreen search -->
			</div>
		</div>
		<!-- offcanvas end  -->

		<!-- shopping-cart-bar start -->
		<div class="cart-menu-right cart-style-1 white-bg">
			<div class="close-icon float-right">
				<a href="javascript:void(0);"><i class="bi bi-x"></i></a>
			</div>
			<div class="dropdown-cart-products">
				<div class="product">
					<div class="product__cart-details">
						<h5 class="product-title">
							<a href="shop.html">Best color ful Lamp for ceiling</a>
						</h5>

						<span class="cart-product-info">
							<span class="cart-product-qty">1</span>
							x $84.00
						</span>
					</div>

					<figure class="product__image-container">
						<a href="shop.html" class="product-img">
							<img src="assets/img/product/cart/product-01.jpg" alt="product">
						</a>
					</figure>
					<a href="#" class="remove-btn" title="Product remove"><i class="fal fa-times"></i></a>
				</div>
				<div class="product">
					<div class="product__cart-details">
						<h5 class="product-title">
							<a href="shop.html">Love color Table Lamp for room</a>
						</h5>

						<span class="cart-product-info">
							<span class="cart-product-qty">1</span>
							x $84.00
						</span>
					</div>

					<figure class="product__image-container">
						<a href="shop.html" class="product-img">
							<img src="assets/img/product/cart/product-02.jpg" alt="product">
						</a>
					</figure>
					<a href="#" class="remove-btn" title="Product remove"><i class="fal fa-times"></i></a>
				</div>
				<div class="product">
					<div class="product__cart-details">
						<h5 class="product-title">
							<a href="shop.html">Best color ful Lamp for ceiling</a>
						</h5>

						<span class="cart-product-info">
							<span class="cart-product-qty">1</span>
							x $84.00
						</span>
					</div>

					<figure class="product__image-container">
						<a href="shop.html" class="product-img">
							<img src="assets/img/product/cart/product-03.jpg" alt="product">
						</a>
					</figure>
					<a href="#" class="remove-btn" title="Product remove"><i class="fal fa-times"></i></a>
				</div>
			</div>

			<div class="cart-total mb-15">
				<span>Total</span>
				<span class="cart-total-price">$160.00</span>
			</div>

			<div class="cart-action">
				<a href="cart.html" class="btn btn-primary">View Cart</a>
				<a href="checkout.html" class="btn btn-outline-primary-2"><span>Checkout</span><i
						class="fal fa-long-arrow-right"></i></a>
			</div>
		</div>
		<!-- shopping-cart-bar end -->

		<!-- slide-bar start -->
		<div class="ht-menu-wrapper">
			<div class="ht-menu-area">
				<button class="ht-menu-toggle"><i class="bi bi-x-lg"></i></button>
				<div class="mobile-logo">
					<a href="index.html">
						<img src="assets/img/logo/logo-2.svg" alt="logo">
					</a>
				</div>
				<div class="mobile-menu-wrapper d-lg-none d-inline-block">
					<div class="mobile-menu"></div>
				</div>
				<div class="offset-widget mb-40">
					<div class="info-widget">
						<h4 class="offset-title mb-20">About Us</h4>
						<p class="mb-30">
							But I must explain to you how all this mistaken idea of denouncing pleasure and
							praising pain was born and will give you a complete account of the system and
							expound the actual teachings of the great explore
						</p>
					</div>
				</div>
				<div class="offset-widget mb-30 pr-10">
					<div class="info-widget info-widget2">
						<h4 class="offset-title mb-20">Contact Info</h4>
						<p>
							<i class="fal fa-address-book"></i>
							23/A, Miranda City Likaoli Prikano, Dope
						</p>
						<p>
							<i class="fal fa-phone"></i>
							+0989 7876 9865 9
						</p>
						<p>
							<i class="fal fa-envelope-open"></i>
							info@example.com
						</p>
					</div>
				</div>
				<div class="login-btn text-center">
					<a class="ht-btn w-100" href="login.html">Login</a>
				</div>

			</div>
		</div>
		<!-- side-bar end -->


		<main>

			<!-- page-title-area start -->
			<div class="page-title-area">
				<div class="breadcrumb-wrapper" data-background="assets/img/page-title/page-title-bg.jpg">
					<div class="container">
						<div class="breadcrumb-content text-center">
							<h2 class="breadcrumb-title">Services</h2>
							<ul class="breadcumb-menu">
								<li><a href="index.html">Home</a></li>
								<li><a href="#">Pages</a></li>
								<li><a href="#">Services</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
			<!-- page-title-area end -->

			<!-- about-section start -->
			<div class="about-section pt-120 pb-55 pb-lg-15 pt-lg-100">
				<div class="container">
					<div
						class="row align-items-center justify-content-md-between justify-content-center mb-95 mb-lg-50">
						<div class="col-xxl-6 col-md-6">
							<div class="title-one">
								<h2 class="title">Always Protecting Life, Business.</h2>
							</div>
						</div>
						<div class="offse-xxl-1 col-xxl-5 col-md-6">
							<div class="title-one">
								<p class="mb-30">Continuously protecting your life and business, offering dependable
									coverage for all
									your vital needs.</p>
								<a href="about.html" class="btn-four">About us</a>
							</div>
						</div>
					</div>
					<div class="row row-cols-md-3 row-cols-1 justify-content-between">
						<div class="col">
							<div class="counter-wrap-4 text-md-start text-center">
								<p class="counter-title">Winning Awards</p>
								<div class="counter-divider"></div>
								<h3 class="number"><span class="counter">146</span>+</h3>
								<p class="description">More than 146 awards won, celebrating excellence and
									recognition
									in various fields.</p>
							</div>
						</div>
						<div class="col d-flex justify-content-md-center">
							<div class="counter-wrap-4 text-md-start text-center">
								<p class="counter-title">Clients</p>
								<div class="counter-divider"></div>
								<h3 class="number"><span class="counter">1.8</span>m+</h3>
								<p class="description pe-xxl-3">Our company has over 1.8 million clients, showcasing
									exceptional
									trust and
									service.</p>
							</div>
						</div>
						<div class="col d-flex justify-content-md-end">
							<div class="counter-wrap-4 text-center text-md-start">
								<p class="counter-title">Expert Members</p>
								<div class="counter-divider"></div>
								<h3 class="number"><span class="counter">13</span>k+</h3>
								<p class="description">Our company boasts over 13,000 expert members, ensuring top-tier
									knowledge
									and service.</p>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- about-section end -->

			<!-- service-section start -->
			<section class="grey-bg service-section pt-120 pb-75 pt-lg-60 pb-lg-15">
				<div class="container">
					<div class="title-one text-lg-start text-center mb-70">
						<h2 class="title">Our Services</h2>
					</div>
					<div class="row align-items-center">
						<div class="col-lg-6">
							<div class="service-wrap-4 white-bg d-md-flex">
								<div class="icon">
									<img class="front-icon" src="assets/img/icon/icon-21.svg" alt="icon">
									<img class="back-icon" src="assets/img/icon/icon-21w.svg" alt="icon">
								</div>
								<div class="content">
									<h4 class="service-title"><a href="services-details.html">Business Insurance</a>
									</h4>
									<p class="description">Life insurance offers lump sums or payments
										to help beneficiaries cover debts
										and expenses.</p>
									<a href="services-details.html" class="more-btn text-capitalize">View More Details
										<img src="assets/img/icon/arrow-7.svg" alt="arrow"></a>
								</div>
							</div>
						</div>
						<div class="col-lg-6">
							<div class="service-wrap-4 white-bg d-md-flex">
								<div class="icon">
									<img class="front-icon" src="assets/img/icon/icon-20.svg" alt="icon">
									<img class="back-icon" src="assets/img/icon/icon-20w.svg" alt="icon">
								</div>
								<div class="content">
									<h4 class="service-title"><a href="services-details.html">Business Insurance</a>
									</h4>
									<p class="description">Life insurance offers lump sums or payments
										to help beneficiaries cover debts
										and expenses.</p>
									<a href="services-details.html" class="more-btn text-capitalize">View More Details
										<img src="assets/img/icon/arrow-7.svg" alt="arrow"></a>
								</div>
							</div>
						</div>
						<div class="col-lg-6">
							<div class="service-wrap-4 white-bg d-md-flex">
								<div class="icon">
									<img class="front-icon" src="assets/img/icon/icon-22.svg" alt="icon">
									<img class="back-icon" src="assets/img/icon/icon-22w.svg" alt="icon">
								</div>
								<div class="content">
									<h4 class="service-title"><a href="services-details.html">Business Insurance</a>
									</h4>
									<p class="description">Life insurance offers lump sums or payments
										to help beneficiaries cover debts
										and expenses.</p>
									<a href="services-details.html" class="more-btn text-capitalize">View More Details
										<img src="assets/img/icon/arrow-7.svg" alt="arrow"></a>
								</div>
							</div>
						</div>
						<div class="col-lg-6">
							<div class="service-wrap-4 white-bg d-md-flex">
								<div class="icon">
									<img class="front-icon" src="assets/img/icon/icon-23.svg" alt="icon">
									<img class="back-icon" src="assets/img/icon/icon-23w.svg" alt="icon">
								</div>
								<div class="content">
									<h4 class="service-title"><a href="services-details.html">Business Insurance</a>
									</h4>
									<p class="description">Life insurance offers lump sums or payments
										to help beneficiaries cover debts
										and expenses.</p>
									<a href="services-details.html" class="more-btn text-capitalize">View More Details
										<img src="assets/img/icon/arrow-7.svg" alt="arrow"></a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
			<!-- service-section end -->

			<!-- cta-section end -->
			<!--<div class="cta-section position-relative pt-140 pb-100 pt-lg-60 pb-lg-60">-->
			<!--	<img class="d-none d-lg-inline-block position-absolute start-0 mt-170 ml-140 top-0 rotation"-->
			<!--		src="assets/img/shape/shape-9.png" alt="shape">-->
			<!--	<img class="d-none d-lg-inline-block position-absolute end-0 mt-170 mr-100 top-0 rotation"-->
			<!--		src="assets/img/shape/shape-9.png" alt="shape">-->
			<!--	<div class="container">-->
			<!--		<div class="row justify-content-center">-->
			<!--			<div class="col-lg-9">-->
			<!--				<div class="title-one text-center">-->
			<!--					<h2 class="title">Have Concerns? Feel Free to Connect.</h2>-->
			<!--					<a href="contact.html" class="ht-btn mt-25">Get a loan</a>-->
			<!--				</div>-->
			<!--			</div>-->
			<!--		</div>-->
			<!--	</div>-->
			<!--</div>-->
			<!-- cta-section end -->

		</main>




		<!--scrollToTopBtn end-->
		<a id="scrollToTopBtn" class="progress-wrap">
			<i class="bi bi-arrow-up"></i>
		</a>


	</div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/u756254243/domains/basilstar.com/public_html/resources/views/services.blade.php ENDPATH**/ ?>
<!-- Header -->
<header id="adminHeader" class="bg-white shadow-sm z-40 fixed w-full top-0 left-0  transition-all duration-200 ease-in-out">
    <div class="flex items-center justify-between px-4 py-3">
        <!-- Left side: Mobile menu button and search -->
        <div class="flex items-center space-x-4">
            <!-- Mobile menu button -->
            <button class="md:hidden text-gray-500" onclick="toggleMobileSidebar()">
                <i class="fas fa-bars"></i>
            </button>
            
            <!-- Desktop sidebar collapse button -->
            <button class="hidden md:block text-gray-500 p-2 rounded-full hover:bg-gray-100" onclick="toggleSidebarCollapse()">
                <i class="fas fa-bars"></i>
            </button>

            <!-- Search -->
            <div class="relative hidden md:block">
                <input type="text" placeholder="Search funds, clients..." class="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent w-64">
                <i class="fas fa-search absolute left-3 top-3 text-gray-400"></i>
            </div>
        </div>
        
        <!-- Right side: Notifications, messages, profile -->
        <div class="flex items-center space-x-4">
            <!-- Market Indicators -->
            <div class="hidden lg:flex items-center space-x-4 mr-4">
                <div class="text-sm">
                    <span class="font-medium">S&P 500:</span>
                    <span class="market-up">4,567.89 <i class="fas fa-caret-up"></i> 0.45%</span>
                </div>
                <div class="text-sm">
                    <span class="font-medium">NASDAQ:</span>
                    <span class="market-down">14,210.34 <i class="fas fa-caret-down"></i> 0.23%</span>
                </div>
                <div class="text-sm">
                    <span class="font-medium">DJIA:</span>
                    <span class="market-up">35,678.12 <i class="fas fa-caret-up"></i> 0.67%</span>
                </div>
            </div>
            
            <!-- Notifications -->
            <button class="relative p-2 text-gray-500 hover:text-gray-700 focus:outline-none">
                <i class="fas fa-bell"></i>
                <span class="absolute top-0 right-0 w-2 h-2 bg-red-500 rounded-full"></span>
            </button>
            
            <!-- Messages -->
            <button class="relative p-2 text-gray-500 hover:text-gray-700 focus:outline-none">
                <i class="fas fa-envelope"></i>
                <span class="absolute top-0 right-0 w-2 h-2 bg-blue-500 rounded-full"></span>
            </button>
            
            <!-- User dropdown -->
            <div class="relative">
                <button id="userDropdownButton" class="flex items-center space-x-2 focus:outline-none">
                    <img src="https://ui-avatars.com/api/?name=Admin+User&background=3b82f6&color=fff" alt="User" class="w-8 h-8 rounded-full">
                    <span class="hidden md:inline text-sm font-medium">Admin User</span>
                    <i class="fas fa-chevron-down text-xs text-gray-500 hidden md:inline"></i>
                </button>
                
                <div id="userDropdown" class="hidden absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-50">
                    <a href="#" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Your Profile</a>
                    <a href="#" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Settings</a>
                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Logout</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</header>

<script>
    // Toggle user dropdown
    const userDropdownButton = document.getElementById('userDropdownButton');
    const userDropdown = document.getElementById('userDropdown');
    
    userDropdownButton.addEventListener('click', (event) => {
        event.stopPropagation(); // Prevent the document click listener from immediately closing it
        userDropdown.classList.toggle('hidden');
    });
    
    // Close dropdown when clicking outside
    document.addEventListener('click', (event) => {
        if (!userDropdown.contains(event.target) && !userDropdownButton.contains(event.target)) {
            userDropdown.classList.add('hidden');
        }
    });
</script>
<?php /**PATH /home/u756254243/domains/basilstar.com/public_html/resources/views/layouts/adminHeader.blade.php ENDPATH**/ ?>
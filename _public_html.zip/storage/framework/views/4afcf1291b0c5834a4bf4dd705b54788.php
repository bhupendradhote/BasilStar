

<?php $__env->startSection('content'); ?>
<div class="max-w-7xl mx-auto mt-10 px-4">
    <h2 class="text-2xl font-bold mb-6 text-gray-800">Add Market Prediction</h2>

    <?php if(session('success')): ?>
        <div class="mb-4 p-3 rounded-md bg-green-100 text-green-700">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('admin.market-prediction.store')); ?>" method="POST" enctype="multipart/form-data" class="bg-white p-6 rounded-lg shadow-md">
        <?php echo csrf_field(); ?>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Title</label>
                <input type="text" name="title" required value="<?php echo e(old('title')); ?>" class="w-full border border-gray-300 rounded-md p-2 focus:ring-2 focus:ring-blue-500">
            </div>

            
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Image</label>
                <input type="file" name="image_file" accept="image/*" class="w-full border border-gray-300 rounded-md p-2 bg-white focus:ring-2 focus:ring-blue-500">
            </div>

            
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Expected Range</label>
                <input type="text" name="range" value="<?php echo e(old('range')); ?>" class="w-full border border-gray-300 rounded-md p-2 focus:ring-2 focus:ring-blue-500">
            </div>

            
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Market Sentiment</label>
                <select name="market_sentiment" class="w-full border border-gray-300 rounded-md p-2 bg-white focus:ring-2 focus:ring-blue-500">
                    <option value="">Select</option>
                    <option value="Bullish" <?php echo e(old('market_sentiment') == 'Bullish' ? 'selected' : ''); ?>>Bullish</option>
                    <option value="Bearish" <?php echo e(old('market_sentiment') == 'Bearish' ? 'selected' : ''); ?>>Bearish</option>
                    <option value="Neutral" <?php echo e(old('market_sentiment') == 'Neutral' ? 'selected' : ''); ?>>Neutral</option>
                </select>
            </div>

            
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Support Levels</label>
                <input type="text" name="support_levels" value="<?php echo e(old('support_levels')); ?>" class="w-full border border-gray-300 rounded-md p-2 focus:ring-2 focus:ring-blue-500">
            </div>

            
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Resistance Levels</label>
                <input type="text" name="resistance_levels" value="<?php echo e(old('resistance_levels')); ?>" class="w-full border border-gray-300 rounded-md p-2 focus:ring-2 focus:ring-blue-500">
            </div>
        </div>

        
        <div class="mt-6 space-y-4">
            
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Description</label>
                <textarea name="description" rows="3" required class="w-full border border-gray-300 rounded-md p-2 focus:ring-2 focus:ring-blue-500"><?php echo e(old('description')); ?></textarea>
            </div>

            
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Global Cues</label>
                <textarea name="global_cues" rows="2" class="w-full border border-gray-300 rounded-md p-2 focus:ring-2 focus:ring-blue-500"><?php echo e(old('global_cues')); ?></textarea>
            </div>

            
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Volatility Alert</label>
                <textarea name="volatility_alert" rows="2" class="w-full border border-gray-300 rounded-md p-2 focus:ring-2 focus:ring-red-500"><?php echo e(old('volatility_alert')); ?></textarea>
            </div>
        </div>

        
        <div class="pt-6">
            <button type="submit" class="w-full md:w-auto px-6 py-2 bg-blue-600 text-white font-semibold rounded-md hover:bg-blue-700 transition">
                Save Prediction
            </button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/u756254243/domains/basilstar.com/public_html/resources/views/admin/market_prediction/create.blade.php ENDPATH**/ ?>
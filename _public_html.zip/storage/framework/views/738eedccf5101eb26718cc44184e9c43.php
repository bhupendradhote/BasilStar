

    <?php $__env->startSection('title', 'liveChart'); ?>

    <?php $__env->startSection('content'); ?>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script src="https://unpkg.com/lightweight-charts@4.1.1/dist/lightweight-charts.standalone.production.js"></script>
    <style>
    .sig_history1, .sig_history2, .sig_history3,.sig_history4, .sig_history7,.sig_history8,.detail-card{
display: none !important;
}
.select2-container--default .select2-selection--single .select2-selection__rendered {
     line-height: 14px !important;
}
        .container {
            background-color: #ffffff;
            border-radius: 1rem;
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.05);
            padding: 2.5rem;
            /*max-width: 100%;*/
                max-width: 900px;
                margin: 0 auto;
        }
        .select2-container {
            width: 100% !important;
        }
        .message-box {
            padding: 1rem;
            border-radius: 0.75rem;
            margin-top: 1.5rem;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }
        .message-box.info { background-color: #e0f7fa; color: #006064; border: 1px solid #80deea; }
        .message-box.success { background-color: #e8f5e9; color: #2e7d32; border: 1px solid #a5d6a7; }
        .message-box.warning { background-color: #fff3e0; color: #ef6c00; border: 1px solid #ffcc80; }
        .message-box.error { background-color: #ffebee; color: #c62828; border: 1px solid #ef9a9a; }
        .analysis-section {
            border: 1px solid #edf2f7;
            border-radius: 0.75rem;
            padding: 1.5rem;
            margin-top: 1.5rem;
            background-color: #fcfcfc;
            box-shadow: inset 0 1px 3px 0 rgba(0,0,0,0.05);
        }
        .section-title {
            font-weight: 700;
            color: #2d3748;
            margin-bottom: 1rem;
            font-size: 1.25rem;
            border-bottom: 2px solid #e2e8f0;
            padding-bottom: 0.5rem;
        }
        .detail-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 1rem;
        }
        .detail-card {
            background-color: #f7fafc;
            border: 1px solid #e2e8f0;
            border-radius: 0.5rem;
            padding: 1rem;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            min-height: 100px;
        }
        .detail-label {
            font-weight: 600;
            color: #4a5568;
            font-size: 0.95rem;
            margin-bottom: 0.25rem;
        }
        .detail-value-container {
            display: flex;
            flex-direction: column;
            align-items: flex-end;
            margin-top: 0.5rem;
        }
        .detail-value {
            color: #2d3748;
            font-size: 1.15rem;
            font-weight: 700;
            text-align: right;
        }
        .detail-date {
            color: #718096;
            font-size: 0.75rem;
            margin-top: 0.25rem;
            text-align: right;
        }
        .trade-recommendation {
            font-size: 1.15rem;
            padding: 1.5rem;
            margin-top: 2rem;
            border-radius: 0.75rem;
            font-weight: 600;
            line-height: 1.6;
            box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1), 0 2px 4px -1px rgba(0,0,0,0.06);
        }
        .trade-recommendation.buy { background-color: #e6ffe6; color: #1b5e20; border: 2px solid #4caf50; }
        .trade-recommendation.sell { background-color: #ffebee; color: #b71c1c; border: 2px solid #f44336; }
        .trade-recommendation.neutral { background-color: #e3f2fd; color: #1565c0; border: 2px solid #2196f3; }
        ul { list-style-type: none; padding-left: 0; margin-top: 0.75rem; }
        ul li { position: relative; padding-left: 1.5rem; margin-bottom: 0.5rem; color: #4a5568; }
        ul li::before { content: '✔️'; position: absolute; left: 0; color: #4CAF50; font-size: 0.9rem; }
        .trade-recommendation.sell ul li::before { content: '❌'; color: #ef5350; }
        .trade-recommendation.neutral ul li::before { content: 'ℹ️'; color: #2196f3; }
        .spinner { border: 4px solid #f3f3f3; border-top: 4px solid #3498db; border-radius: 50%; width: 30px; height: 30px; animation: spin 1s linear infinite; margin: 0 auto; }
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }

        /* Chart and Toggle Styles */
        #chart-container {
            background-color: #ffffff;
            border-radius: 0.75rem;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -2px rgba(0, 0, 0, 0.1);
            height: 500px;
            width: 100%;
            padding: 1rem;
            box-sizing: border-box;
            position: relative;
            display: none;
        }
        #chart { width: 100%; height: 100%; }
        .toggle-switch { position: relative; display: inline-block; width: 38px; height: 22px; }
        .toggle-switch input { opacity: 0; width: 0; height: 0; }
        .toggle-slider { position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background-color: #ccc; transition: .4s; border-radius: 22px; }
        .toggle-slider:before { position: absolute; content: ""; height: 16px; width: 16px; left: 3px; bottom: 3px; background-color: white; transition: .4s; border-radius: 50%; }
        input:checked + .toggle-slider { background-color: #2196F3; }
        input:focus + .toggle-slider { box-shadow: 0 0 1px #2196F3; }
        input:checked + .toggle-slider:before { transform: translateX(16px); }

        .select2-results__option
 {
    padding: 6px;
    user-select: none;
    -webkit-user-select: none;
    padding-left: 30px !important;
}
    </style>
    <div class="container">
        <h1 class="text-3xl font-extrabold text-gray-900 mb-6 text-center tracking-tight">
            Advanced Stock Analysis
        </h1>

        <div class="mb-6">
            <label for="stockSelector" class="block text-gray-700 text-base font-bold mb-2">Select a Stock to Analyze:</label>
            <select id="stockSelector" class="w-full p-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"></select>
        </div>

        <div id="loading" class="text-center mb-6 hidden">
            <div class="spinner"></div>
            <p class="text-gray-600 mt-3">Analyzing stock data...</p>
        </div>
        <!--<div id="error-message" class="message-box error hidden"></div>-->

        <div id="analysis-output" class="analysis-section hidden">
            <h2 class="section-title">Analysis for <span id="currentSymbolDisplay" class="text-blue-600"></span>  <span id="currentPriceDisplay" class="detail-value text-blue-700">N/A</span>
                        <span id="currentPriceDate" class="detail-date"></span></h2>
            <div class="detail-grid">
                <div class="detail-card">
                    <span class="detail-label">Current Price:</span>
                    <div class="detail-value-container">
                        <span id="currentPriceDisplay" class="detail-value text-blue-700">N/A</span>
                        <span id="currentPriceDate" class="detail-date"></span>
                    </div>
                </div>
                <div class="detail-card">
                    <span class="detail-label">Latest SMA Signal (10-Day):</span>
                    <div class="detail-value-container">
                        <span id="latestSmaSignalDisplay" class="detail-value">N/A</span>
                        <span id="latestSmaSignalDate" class="detail-date"></span>
                    </div>
                </div>
                <div class="detail-card">
                    <span class="detail-label">Latest Swing High:</span>
                    <div class="detail-value-container">
                        <span id="latestSwingHighDisplay" class="detail-value">N/A</span>
                        <span id="latestSwingHighDate" class="detail-date"></span>
                    </div>
                </div>
                <div class="detail-card">
                    <span class="detail-label">Latest Swing Low:</span>
                    <div class="detail-value-container">
                        <span id="latestSwingLowDisplay" class="detail-value">N/A</span>
                        <span id="latestSwingLowDate" class="detail-date"></span>
                    </div>
                </div>
                <div class="detail-card">
                    <span class="detail-label">Market Structure 0.5 Fib (Latest):</span>
                    <div id="msFibDetails" class="mt-1">N/A</div>
                </div>
                <div class="detail-card">
                    <span class="detail-label">Overall Fibonacci 0.5 Level:</span>
                    <div class="detail-value-container">
                        <span id="overallFibDisplay" class="detail-value">N/A</span>
                        <span id="overallFibDate" class="detail-date"></span>
                    </div>
                </div>
            </div>

            <h2 style="display:none;" class="section-title mt-8">Trade Recommendation & Strategy</h2>
            <div id="tradeRecommendationOutput" class="trade-recommendation"></div>

            <h2 style="display:none;" class="section-title mt-8">Interactive Chart Analysis</h2>
            <div style="display:none;" class="mb-4 flex flex-wrap gap-x-6 gap-y-2 justify-center">
                <div class="flex items-center space-x-2">
                    <label for="toggleSma" class="text-gray-700 text-sm">10-SMA</label>
                    <label class="toggle-switch"><input type="checkbox" id="toggleSma" checked><span class="toggle-slider"></span></label>
                </div>
                <div class="flex items-center space-x-2">
                    <label for="toggleOverallFib" class="text-gray-700 text-sm">Overall Fib</label>
                    <label class="toggle-switch"><input type="checkbox" id="toggleOverallFib" checked><span class="toggle-slider"></span></label>
                </div>
                <div class="flex items-center space-x-2">
                    <label for="toggleMarketStructureFib" class="text-gray-700 text-sm">MS Fib</label>
                    <label class="toggle-switch"><input type="checkbox" id="toggleMarketStructureFib" checked><span class="toggle-slider"></span></label>
                </div>
                <div class="flex items-center space-x-2">
                    <label for="toggleSwingPoints" class="text-gray-700 text-sm">Swing H/L</label>
                    <label class="toggle-switch"><input type="checkbox" id="toggleSwingPoints" checked><span class="toggle-slider"></span></label>
                </div>
                 <div class="flex items-center space-x-2">
                    <label for="toggleSmaSignals" class="text-gray-700 text-sm">SMA Signals</label>
                    <label class="toggle-switch"><input type="checkbox" id="toggleSmaSignals" checked><span class="toggle-slider"></span></label>
                </div>
                <div class="flex items-center space-x-2">
                    <label for="togglePreviousMSFib" class="text-gray-700 text-sm">Previous MS Fib</label>
                    <label class="toggle-switch"><input type="checkbox" id="togglePreviousMSFib" checked><span class="toggle-slider"></span></label>
                </div>
            </div>
            <div id="chart-container">
                <div id="chart"></div>
            </div>
        </div>
    </div>

    <script type="module">
        const TWELVE_DATA_API_KEY = 'e2fb0acfee10401da4f7151094e4e6b2'; // Your Twelve Data API Key

        // --- Global Data Holders ---
        let currentStockData = null; // Raw candle data
        let currentSMA = null;       // SMA data and signals
        let currentSwingPoints = null; // Swing high/low data
        let currentMarketStructure = null; // Market Structure Fib data
        let currentOverallFib = null;    // Overall Fib data
        let currentPrice = null;     // Current live price
        let previousMarketStructures = []; // Array to store previous market structures

        // --- Chart Variables ---
        let chart, candleSeries, smaSeries;
        let overallFibonacciLines = [];
        let marketStructureFibonacciLines = [];
        let previousMarketStructureLines = [];
        let swingHighMarkers = [];
        let swingLowMarkers = [];
        let smaSignalMarkers = [];


        /**
         * Displays a message in the designated message box.
         */
        function showMessageBox(msg, type, targetId = 'error-message') {
            const messageBox = $(`#${targetId}`);
            messageBox.removeClass().addClass(`message-box ${type}`).html(msg).removeClass('hidden');
        }

        /**
         * Hides a message box.
         */
        function hideMessageBox(targetId = 'error-message') {
            $(`#${targetId}`).addClass('hidden');
        }

        /**
         * Fetches a list of stock symbols from the Twelve Data API.
         */
        async function loadSymbolsFromApi(exchange = 'NSE') {
            const apiUrl = `https://api.twelvedata.com/stocks?exchange=${exchange}&apikey=${TWELVE_DATA_API_KEY}&show_plan=true`;
            try {
                const response = await fetch(apiUrl);
                const data = await response.json();
                const dropdown = $('#stockSelector');
                dropdown.empty();

                if (data.status === 'error' || !data.data || data.data.length === 0) {
                    showMessageBox(`No symbols received for ${exchange}. <br>Error: ${data.message || 'Unknown API error.'}`, 'error');
                    return;
                }

                data.data.forEach(stock => {
                    if (stock.currency === "INR") {
                        dropdown.append(`<option value="${stock.symbol}">${stock.name} (${stock.symbol})</option>`);
                    }
                });

                dropdown.select2({ placeholder: `Search stocks in ${exchange}...`, allowClear: true });
                const defaultSymbol = dropdown.val();
                if (defaultSymbol) await analyzeStock(defaultSymbol);
                else {
                    $('#analysis-output').addClass('hidden');
                    showMessageBox('Please select a stock to begin analysis.', 'info');
                }
                dropdown.on('change', async function() { if ($(this).val()) await analyzeStock($(this).val()); });
            } catch (error) {
                showMessageBox(`Failed to load symbols. <br>Please check API key or network.`, 'error');
            }
        }

        /**
         * Fetches historical daily candle data for a given symbol.
         * @param {string} symbol - The stock symbol.
         * @returns {Promise<Array<Object>>} - An array of candle data.
         */
        async function fetchHistoricalCandles(symbol) {
            const apiUrl = `https://api.twelvedata.com/time_series?symbol=${symbol}&interval=1day&outputsize=1000&apikey=${TWELVE_DATA_API_KEY}`;
            const response = await fetch(apiUrl);
            const data = await response.json();
            if (data.status === 'error' || !data.values) throw new Error(data.message || 'No daily data found.');
            return data.values.reverse().map((item, index) => ({
                time: item.datetime.split(' ')[0], open: parseFloat(item.open), high: parseFloat(item.high), low: parseFloat(item.low), close: parseFloat(item.close), index: index
            })).filter(item => !isNaN(item.open) && !isNaN(item.high) && !isNaN(item.low) && !isNaN(item.close));
        }

        /**
         * Fetches the current live price for a given symbol.
         * @param {string} symbol - The stock symbol.
         * @returns {Promise<number|null>} - The current price or null if not available.
         */
        async function fetchCurrentPrice(symbol) {
            const apiUrl = `https://api.twelvedata.com/price?symbol=${symbol}&apikey=${TWELVE_DATA_API_KEY}`;
            const response = await fetch(apiUrl);
            const data = await response.json();
            if (data.status === 'error' || !data.price) { console.warn(`Could not fetch current price for ${symbol}`); return null; }
            return parseFloat(data.price);
        }

        /**
         * Calculates the Simple Moving Average (SMA) for a given data set.
         * @param {Array<Object>} data - Array of candle data.
         * @param {number} period - The SMA period.
         * @returns {Array<Object>} - Array of SMA values.
         */
        function calculateSMA(data, period = 10) {
            const sma = [];
            if (data.length < period) return [];
            for (let i = period - 1; i < data.length; i++) {
                const sum = data.slice(i - period + 1, i + 1).reduce((acc, val) => acc + val.close, 0);
                sma.push({ time: data[i].time, value: sum / period });
            }
            return sma;
        }

        /**
         * Detects SMA crossover buy/sell signals.
         * @param {Array<Object>} data - Array of candle data.
         * @param {Array<Object>} smaData - Array of SMA data.
         * @param {number} smaPeriod - The SMA period used.
         * @returns {Array<Object>} - Array of detected signals.
         */
        function detectSMASignals(data, smaData, smaPeriod = 10) {
            const signals = [];
            for (let i = 1; i < smaData.length; i++) {
                const priceIndex = i + smaPeriod - 1;
                const prevPriceIndex = i + smaPeriod - 2;
                if (!data[priceIndex] || !data[prevPriceIndex]) continue;

                // Crossover detection: Price crosses above SMA (Buy), Price crosses below SMA (Sell)
                if (data[prevPriceIndex].close < smaData[i-1].value && data[priceIndex].close > smaData[i].value) {
                    signals.push({ time: data[priceIndex].time, type: 'Buy', price: data[priceIndex].close });
                } else if (data[prevPriceIndex].close > smaData[i-1].value && data[priceIndex].close < smaData[i].value) {
                    signals.push({ time: data[priceIndex].time, type: 'Sell', price: data[priceIndex].close });
                }
            }
            return signals;
        }

        /**
         * Finds swing highs and lows in the data.
         * A swing high is a bar whose high is higher than 'lookback' bars before and after it.
         * A swing low is a bar whose low is lower than 'lookback' bars before and after it.
         * @param {Array<Object>} data - Array of candle data.
         * @param {number} lookback - Number of bars to look back/forward.
         * @returns {Object} - Contains latest swing high/low and all detected points.
         */
        function findSwingHighLows(data, lookback = 5) {
            const swingHighs = [];
            const swingLows = [];

            for (let i = lookback; i < data.length - lookback; i++) {
                let isHigh = true;
                for (let j = 1; j <= lookback; j++) {
                    if (data[i - j].high > data[i].high || data[i + j].high > data[i].high) {
                        isHigh = false;
                        break;
                    }
                }
                if (isHigh) {
                    swingHighs.push({ price: data[i].high, time: data[i].time, index: i });
                }

                let isLow = true;
                for (let j = 1; j <= lookback; j++) {
                    if (data[i - j].low < data[i].low || data[i + j].low < data[i].low) {
                        isLow = false;
                        break;
                    }
                }
                if (isLow) {
                    swingLows.push({ price: data[i].low, time: data[i].time, index: i });
                }
            }
            return {
                latestHigh: swingHighs.length > 0 ? swingHighs[swingHighs.length - 1] : null,
                latestLow: swingLows.length > 0 ? swingLows[swingLows.length - 1] : null,
                allHighs: swingHighs,
                allLows: swingLows
            };
        }

        /**
         * Calculates Fibonacci retracement levels between a top and a bottom.
         * @param {number} _top - The high price of the structure.
         * @param {number} _bot - The low price of the structure.
         * @param {number} _dir - Direction of the fib drawing (1 for bullish pull, -1 for bearish pull).
         * @returns {Object} - Object containing Fibonacci levels.
         */
        function getFibs(_top, _bot, _dir) {
            const levels = [0, 0.236, 0.382, 0.5, 0.618, 0.786, 1];
            const fibValues = {};
            const rng = Math.abs(_top - _bot);

            levels.forEach(level => {
                let value;
                if (_dir === 1) { // Bullish Fib: Retracement from Low (0) to High (1)
                    value = _bot + (rng * level);
                } else { // Bearish Fib: Retracement from High (0) to Low (1)
                    value = _top - (rng * level);
                }
                fibValues[level.toFixed(3)] = value;
            });
            return fibValues;
        }

        /**
         * Calculates Market Structure based on the most recent swing high and swing low,
         * and then determines Fibonacci levels for that structure.
         * This aims to capture "small structures" by using recent pivot points.
         * @param {Array<Object>} data - Array of candle data.
         * @returns {Object|null} - Latest market structure fib details.
         */
        function calculateMarketStructure(data) {
            // Use a small lookback for finding recent swing points for "small structures"
            const structureLen = 5; // Smaller lookback for more reactive structure detection

            const swingPoints = findSwingHighLows(data, structureLen);
            const allHighs = swingPoints.allHighs;
            const allLows = swingPoints.allLows;

            if (allHighs.length < 1 || allLows.length < 1) {
                return null; // Not enough swing points to define a structure
            }

            // Get the most recent swing high and swing low
            const lastHigh = allHighs[allHighs.length - 1];
            const lastLow = allLows[allLows.length - 1];

            if (!lastHigh || !lastLow) return null;

            let structureTop, structureBottom, dir;

            // Determine the direction (bullish or bearish) of the market structure
            // based on the chronological order of the last high and last low.
            if (lastHigh.time > lastLow.time) {
                // If the last swing high occurred *after* the last swing low, it suggests a bullish move
                // (e.g., a higher low followed by a higher high implies bullish market structure)
                dir = 1; // Bullish structure
                structureBottom = lastLow.price;
                structureTop = lastHigh.price;
            } else {
                // If the last swing low occurred *after* the last swing high, it suggests a bearish move
                // (e.g., a lower high followed by a lower low implies bearish market structure)
                dir = -1; // Bearish structure
                structureTop = lastHigh.price;
                structureBottom = lastLow.price;
            }

            // Ensure top is always higher than bottom for consistent fib calculation
            if (structureTop < structureBottom) {
                [structureTop, structureBottom] = [structureBottom, structureTop]; // Swap if inverted
                dir = dir * -1; // Reverse direction if points were swapped, to maintain fib logic
            }


            // Find the index of the earliest of the two defining points for plotting start
            const startIndex = Math.min(lastHigh.index, lastLow.index);
            // The fib lines should extend to the current bar for visual relevance
            const endIndex = data.length - 1;

            const fibLevels = getFibs(structureTop, structureBottom, dir);
            const fib0_5 = fibLevels["0.500"];
            const currentClose = data[data.length - 1].close; // Use latest candle close
            const breakout = currentClose > fib0_5 ? 'above 0.5' : 'below 0.5';

            return {
                type: dir === 1 ? 'bullish' : 'bearish',
                time: data[data.length - 1].time, // Current bar's time
                top: structureTop,
                bottom: structureBottom,
                fib0_5_level: fib0_5,
                breakout: breakout,
                allLevels: fibLevels,
                startIndex: startIndex,
                endIndex: endIndex
            };
        }

        /**
         * Identifies and returns previous market structures
         * @param {Array<Object>} data - Array of candle data
         * @param {number} count - Number of previous structures to find
         * @returns {Array<Object>} - Array of previous market structures
         */
        function findPreviousMarketStructures(data, count = 10) {
            const structures = [];
            const structureLen = 5; // Same as in calculateMarketStructure
            
            // We'll work with a copy of the data to avoid modifying the original
            let workingData = [...data];
            
            // Find the most recent structure first
            let currentStructure = calculateMarketStructure(workingData);
            if (!currentStructure) return [];
            
            // Store the current structure as the first one
            structures.push(currentStructure);
            
            // Now find previous structures by looking at data before the current structure
            while (structures.length < count) {
                // Get the start index of the current structure
                const currentStartIndex = currentStructure.startIndex;
                
                // If we've gone back too far, break the loop
                if (currentStartIndex <= structureLen * 2) break;
                
                // Look at data up to the start of the current structure
                workingData = workingData.slice(0, currentStartIndex);
                
                // Calculate the previous structure
                const prevStructure = calculateMarketStructure(workingData);
                if (!prevStructure) break;
                
                // Add to our collection
                structures.push(prevStructure);
                
                // Set this as the current structure for next iteration
                currentStructure = prevStructure;
            }
            
            // Remove the first structure (the current one) since we already have that
            structures.shift();
            
            return structures;
        }

        /**
         * Calculates the overall Fibonacci retracement levels for the entire historical data.
         * @param {Array<Object>} data - Array of candle data.
         * @returns {Object|null} - Overall Fibonacci levels and range details.
         */
        function calculateOverallFibonacciRetracement(data) {
            if (data.length === 0) return null;
            let highestHigh = -Infinity, lowestLow = Infinity;
            let highestHighTime = null, lowestLowTime = null;

            data.forEach(item => {
                if (item.high > highestHigh) {
                    highestHigh = item.high;
                    highestHighTime = item.time;
                }
                if (item.low < lowestLow) {
                    lowestLow = item.low;
                    lowestLowTime = item.time;
                }
            });

            if (highestHigh === -Infinity || lowestLow === Infinity) return null;

            const diff = highestHigh - lowestLow;
            // Fib 0.5 retracement is calculated from the highest high downwards to lowest low
            const fib0_5 = highestHigh - (diff * 0.5);

            return {
                highestHigh: highestHigh,
                highestHighTime: highestHighTime,
                lowestLow: lowestLow,
                lowestLowTime: lowestLowTime,
                fib0_5_level: fib0_5,
                levels: {
                    "1.000": highestHigh,
                    "0.786": highestHigh-(diff*0.786),
                    "0.618": highestHigh-(diff*0.618),
                    "0.500": fib0_5,
                    "0.382": highestHigh-(diff*0.382),
                    "0.236": highestHigh-(diff*0.236),
                    "0.000": lowestLow
                }
            };
        }

        function generateTradeAnalysisReport(symbol) {
            let recommendation = "", tradeType = 'neutral', reasons = [], targets = [], stopLoss = null, stopLossReason = "";
            if (!currentStockData || currentStockData.length === 0 || currentPrice === null || !currentMarketStructure || !currentOverallFib) {
                return { recommendation: "Insufficient data for a definitive analysis based on requested criteria.", type: 'neutral', reasons: [], targets: [], stopLoss: null, stopLossReason: "" };
            }

            const priceText = `<span class="font-bold text-blue-600">${currentPrice.toFixed(2)}</span>`;
            const currentClose = currentStockData[currentStockData.length - 1].close;

            // --- Add all reasons based on existing indicators (SMA, Swing Points, MS Fib, Overall Fib) ---
            // SMA Signal
            if (currentSMA && currentSMA.signals.length > 0) {
                const latestSmaSignal = currentSMA.signals[currentSMA.signals.length - 1];
                reasons.push(`<strong>SMA Signal:</strong> Recent <strong>${latestSmaSignal.type}</strong> signal on ${latestSmaSignal.time} at ${latestSmaSignal.price.toFixed(2)}.`);
            } else {
                reasons.push(`<strong>SMA Signal:</strong> No clear recent SMA crossover detected.`);
            }

            // Swing High/Low
            const swingHigh = currentSwingPoints?.latestHigh;
            const swingLow = currentSwingPoints?.latestLow;

            if (swingHigh && currentPrice > swingHigh.price) {
                reasons.push(`<strong>Momentum:</strong> Price ${priceText} is <strong>ABOVE</strong> the latest swing high (${swingHigh.price.toFixed(2)}), suggesting bullish momentum and a potential breakout.`);
            } else if (swingHigh) {
                reasons.push(`<strong>Resistance:</strong> Latest swing high at ${swingHigh.price.toFixed(2)} may act as resistance if price moves higher.`);
            }

            if (swingLow && currentPrice < swingLow.price) {
                reasons.push(`<strong>Momentum:</strong> Price ${priceText} is <strong>BELOW</strong> the latest swing low (${swingLow.price.toFixed(2)}), suggesting bearish momentum and a potential breakdown.`);
            } else if (swingLow) {
                reasons.push(`<strong>Support:</strong> Latest swing low at ${swingLow.price.toFixed(2)} may act as support if price moves lower.`);
            }

            // Market Structure Fibonacci
            const { type: msType, fib0_5_level: msFib0_5, breakout: msBreakout, top: msTop, bottom: msBottom } = currentMarketStructure;
            reasons.push(`<strong>Market Structure:</strong> Latest MS Fib is <strong>${msType.toUpperCase()}</strong> (${msBottom.toFixed(2)} - ${msTop.toFixed(2)}). 0.5 level is ${msFib0_5.toFixed(2)}. Price is <strong>${msBreakout.toUpperCase()}</strong>.`);

            // Overall Fibonacci
            const { fib0_5_level: overallFib0_5 } = currentOverallFib;
            const overallFibBreakout = currentPrice > overallFib0_5 ? 'above' : 'below';
            reasons.push(`<strong>Overall Fibonacci 0.5 Level:</strong> This key pivot is at ${overallFib0_5.toFixed(2)}. The current price ${priceText} is <strong>${overallFibBreakout.toUpperCase()}</strong> this level.`);


            // --- Core Trade Decision Logic based on MS Fib 0.5 for Entry ---
            const tolerance = 0.01; // Increased tolerance to 1% for consolidation detection

            // Condition for BUY: Candle closed above MS Fib 0.5
            if (currentClose > msFib0_5 && (currentClose - msFib0_5) > (msFib0_5 * tolerance) ) { // Ensure a clear close above
                tradeType = 'buy';
                recommendation = "<strong>Strong BUY Signal Detected!</strong> The daily candle has closed decisively above the Market Structure 0.5 Fibonacci level, indicating bullish intent.";
                reasons.push(`<strong>Primary Buy Trigger:</strong> Daily candle closed at ${currentClose.toFixed(2)}, which is above the Market Structure 0.5 Fib level (${msFib0_5.toFixed(2)}).`);

                // Set Stop Loss based on MS Fib bottom for a buy trade
                stopLoss = msBottom.toFixed(2);
                stopLossReason = `Place stop loss at the Market Structure bottom (${msBottom.toFixed(2)}). If price drops below this level after entry, the bullish market structure may be invalidated.`;

                // Set Targets based on Overall Fib levels above current price
                let tempTargets = [];
                // Collect all Overall Fib levels above currentClose
                for (const levelKey in currentOverallFib.levels) {
                    const levelValue = currentOverallFib.levels[levelKey];
                    if (levelValue > currentClose) {
                        tempTargets.push({ value: levelValue, label: `Overall Fib ${levelKey}` });
                    }
                }
                tempTargets.sort((a, b) => a.value - b.value); // Sort ascending (nearest to farthest for buy)
                targets = tempTargets.map((t, index) => `T${index + 1}: ${t.label}: ${t.value.toFixed(2)}`);


            }
            // Condition for SELL: Candle closed below MS Fib 0.5
            else if (currentClose < msFib0_5 && (msFib0_5 - currentClose) > (msFib0_5 * tolerance) ) { // Ensure a clear close below
                tradeType = 'sell';
                recommendation = "<strong>Strong SELL Signal Detected!</strong> The daily candle has closed decisively below the Market Structure 0.5 Fibonacci level, indicating bearish intent.";
                reasons.push(`<strong>Primary Sell Trigger:</strong> Daily candle closed at ${currentClose.toFixed(2)}, which is below the Market Structure 0.5 Fib level (${msFib0_5.toFixed(2)}).`);

                // Set Stop Loss based on MS Fib top for a sell trade
                stopLoss = msTop.toFixed(2);
                stopLossReason = `Place stop loss at the Market Structure top (${msTop.toFixed(2)}). If price rises above this level after entry, the bearish market structure may be invalidated.`;

                // Set Targets based on Overall Fib levels below current price
                let tempTargets = [];
                // Collect all Overall Fib levels below currentClose
                for (const levelKey in currentOverallFib.levels) {
                    const levelValue = currentOverallFib.levels[levelKey];
                    if (levelValue < currentClose) {
                        tempTargets.push({ value: levelValue, label: `Overall Fib ${levelKey}` });
                    }
                }
                tempTargets.sort((a, b) => b.value - a.value); // Sort descending (nearest to farthest for sell)
                targets = tempTargets.map((t, index) => `T${index + 1}: ${t.label}: ${t.value.toFixed(2)}`);

            } else { // Price is consolidating or unclear around MS Fib 0.5
                tradeType = 'neutral';
                recommendation = "<strong>Neutral / Consolidating Market.</strong> Price is near the Market Structure 0.5 Fib level, awaiting a clear breakout or breakdown for a directional trade.";
                reasons.push(`<strong>Neutral State:</strong> Current price ${priceText} is consolidating around the Market Structure 0.5 Fib level (${msFib0_5.toFixed(2)}).`);
                reasons.push("Consider waiting for a clear close above or below this level on the daily timeframe for a strong directional signal.");
            }

            return { recommendation, type: tradeType, reasons, targets, stopLoss, stopLossReason };
        }

        /**
         * Main orchestration function to fetch data, analyze, and display everything.
         */
        async function analyzeStock(symbol) {
            $('#loading').removeClass('hidden');
            hideMessageBox('error-message');
            $('#analysis-output').addClass('hidden'); // Initially hide while loading
            $('#currentSymbolDisplay').text(symbol);

            try {
                // Fetch daily candles and current price concurrently
                const [dailyCandles, price] = await Promise.all([
                    fetchHistoricalCandles(symbol),
                    fetchCurrentPrice(symbol)
                ]);

                if (dailyCandles.length === 0) throw new Error("No historical daily data available.");

                // Store data globally
                currentStockData = dailyCandles;
                currentPrice = price;

                // Perform analysis
                const smaPeriod = 10;
                const smaData = calculateSMA(currentStockData, smaPeriod);
                currentSMA = { data: smaData, signals: detectSMASignals(currentStockData, smaData, smaPeriod) };
                currentSwingPoints = findSwingHighLows(currentStockData); // Used for UI display and chart markers
                currentMarketStructure = calculateMarketStructure(currentStockData); // Modified for small structures
                previousMarketStructures = findPreviousMarketStructures(currentStockData, 10); // Find previous 10 market structures
                currentOverallFib = calculateOverallFibonacciRetracement(currentStockData);

                // --- Display Analysis in UI Cards ---
                $('#currentPriceDisplay').text(currentPrice ? currentPrice.toFixed(2) : 'N/A');
                $('#currentPriceDate').text(currentStockData.length > 0 ? `(Live)` : '');

                const latestSmaSignal = currentSMA.signals.length > 0 ? currentSMA.signals[currentSMA.signals.length - 1] : null;
                $('#latestSmaSignalDisplay').text(latestSmaSignal ? `${latestSmaSignal.type} @ ${latestSmaSignal.price.toFixed(2)}` : 'N/A');
                $('#latestSmaSignalDate').text(latestSmaSignal ? `on ${latestSmaSignal.time}` : '');

                $('#latestSwingHighDisplay').text(currentSwingPoints.latestHigh ? `${currentSwingPoints.latestHigh.price.toFixed(2)}` : 'N/A');
                $('#latestSwingHighDate').text(currentSwingPoints.latestHigh ? `on ${currentSwingPoints.latestHigh.time}` : '');
                $('#latestSwingLowDisplay').text(currentSwingPoints.latestLow ? `${currentSwingPoints.latestLow.price.toFixed(2)}` : 'N/A');
                $('#latestSwingLowDate').text(currentSwingPoints.latestLow ? `on ${currentSwingPoints.latestLow.time}` : '');

                // Market Structure Display
                if (currentMarketStructure) {
                    const { type, top, bottom, fib0_5_level, breakout, time } = currentMarketStructure;
                    const typeColor = type === 'bullish' ? 'text-green-600' : 'text-red-600';
                    const msHtml = `
                        <div class="text-sm text-right">
                            <div class="text-left"><strong>Type:</strong> <span class="font-bold ${typeColor}">${type}</span></div>
                            <div class="text-left"><strong>Range:</strong> ${bottom.toFixed(2)} - ${top.toFixed(2)}</div>
                            <div class="font-bold text-base mt-1 text-right">${fib0_5_level.toFixed(2)} (${breakout})</div>
                            <div class="text-xs text-gray-500 mt-1 text-right">based on structure identified near ${time}</div>
                        </div>`;
                    $('#msFibDetails').html(msHtml);
                } else {
                    $('#msFibDetails').html('<div class="detail-value-container"><span class="detail-value">N/A</span></div>');
                }

                // Overall Fibonacci 0.5 Level Display
                if (currentOverallFib) {
                    $('#overallFibDisplay').text(`${currentOverallFib.fib0_5_level.toFixed(2)}`);
                    let overallFibText = `(from ${currentOverallFib.lowestLow.toFixed(2)} on ${currentOverallFib.lowestLowTime} to ${currentOverallFib.highestHigh.toFixed(2)} on ${currentOverallFib.highestHighTime})`;
                    $('#overallFibDate').html(overallFibText);
                } else {
                    $('#overallFibDisplay').text('N/A');
                    $('#overallFibDate').text('');
                }

                // --- Display Trade Recommendation ---
                const tradeReport = generateTradeAnalysisReport(symbol);
                const tradeRecommendationOutput = $('#tradeRecommendationOutput');
                tradeRecommendationOutput.removeClass().addClass(`trade-recommendation ${tradeReport.type}`);
                let reportHtml = `<p>${tradeReport.recommendation}</p>`;
                if (tradeReport.reasons.length > 0) {
                    reportHtml += `<p class="mt-4 font-semibold">Analysis of Key Indicators:</p><ul>${tradeReport.reasons.map((r, index) => `<li class="sig_history sig_history${index + 1}">${r}</li>`).join('')}</ul>`;
                }
                if (tradeReport.stopLoss) {
                    reportHtml += `<p class="mt-4 font-semibold">Suggested Stop Loss: <span class="font-bold">${tradeReport.stopLoss}</span></p><p class="text-sm italic mt-1">${tradeReport.stopLossReason}</p>`;
                }
                if (tradeReport.targets.length > 0) {
                    reportHtml += `<p class="mt-2 font-semibold">Potential Targets:</p><ul>${tradeReport.targets.map(t => `<li>${t}</li>`).join('')}</ul>`;
                }
                tradeRecommendationOutput.html(reportHtml);

                // Make the analysis output (including chart container) visible BEFORE chart creation
                $('#analysis-output').removeClass('hidden');
                await displayChartAndIndicators(symbol, currentStockData);

            } catch (error) {
                showMessageBox(`Error analyzing stock: ${error.message}`, 'error');
                $('#analysis-output').addClass('hidden');
            } finally {
                $('#loading').addClass('hidden');
            }
        }

        /**
         * Initializes and displays the Lightweight Charts chart with various indicators.
         * @param {string} symbol - The stock symbol.
         * @param {Array<Object>} chartData - Historical candle data to display.
         */
        async function displayChartAndIndicators(symbol, chartData) {
            if (chart) chart.remove(); // Dispose of the old chart
            $('#chart').html(''); // Clear the div

            // Clear previous series/markers
            overallFibonacciLines = [];
            marketStructureFibonacciLines = [];
            previousMarketStructureLines = [];
            swingHighMarkers = [];
            swingLowMarkers = [];
            smaSignalMarkers = [];

            chart = LightweightCharts.createChart(document.getElementById('chart'), {
                layout: { background: { color: '#ffffff' }, textColor: '#333' },
                grid: { vertLines: { color: '#eee' }, horzLines: { color: '#eee' }, },
                timeScale: {
                    timeVisible: true,
                    secondsVisible: false,
                    rightOffset: 12,
                    barSpacing: 10
                },
                crosshair: { mode: 1 },
                rightPriceScale: {
                    autoScale: true,
                },
                localization: {
                    priceFormatter: price => price.toFixed(2),
                    timeFormatter: time => new Date(time * 1000).toLocaleDateString()
                }
            });

            candleSeries = chart.addCandlestickSeries({
                upColor: '#4CAF50', // Green
                downColor: '#EF5350', // Red
                borderUpColor: '#4CAF50',
                borderDownColor: '#EF5350',
                wickUpColor: '#4CAF50',
                wickDownColor: '#EF5350'
            });
            candleSeries.setData(chartData);

            // 1. SMA (10-day)
            const smaData = calculateSMA(chartData, 10);
            smaSeries = chart.addLineSeries({ color: 'blue', lineWidth: 2, title: `10 SMA` });
            smaSeries.setData(smaData);

            // 2. SMA Signals as markers
            const smaSignals = currentSMA.signals.map(signal => {
                return {
                    time: signal.time,
                    position: signal.type === 'Buy' ? 'belowBar' : 'aboveBar',
                    color: signal.type === 'Buy' ? '#26A69A' : '#EF5350',
                    shape: 'arrowUp',
                    text: `${signal.type} Signal @ ${signal.price.toFixed(2)}`
                };
            });
            candleSeries.setMarkers(smaSignals);
            smaSignalMarkers = smaSignals; // Keep track for toggling

            // 3. Overall Fib
            const overallFibLevels = currentOverallFib;
            if(overallFibLevels) {
                const fibColors = ['#78909C', '#FFD54F', '#EF5350', '#AB47BC', '#FFA726', '#66BB6A', '#42A5F5']; // Grey, Yellow, Red, Purple, Orange, Green, Blue
                Object.entries(overallFibLevels.levels).forEach(([levelKey, levelValue], i) => {
                    const fibLine = chart.addLineSeries({
                        color: fibColors[i % fibColors.length],
                        lineWidth: 1,
                        lineStyle: LightweightCharts.LineStyle.Dotted,
                        title: `Overall Fib ${levelKey}`
                    });
                    fibLine.setData(chartData.map(d => ({ time: d.time, value: levelValue })));
                    overallFibonacciLines.push(fibLine);
                });
            }

            // 4. Market Structure Fib (Current)
            const msFib = currentMarketStructure;
            if (msFib && chartData.length > 0) {
                const msColor = msFib.type === 'bullish' ? 'rgba(8, 153, 129, 0.8)' : 'rgba(242, 54, 69, 0.8)'; // Green/Red with opacity

                // Relevant data for plotting MS Fib lines.
                // Start the lines from the earliest swing point that defines the structure.
                // End them at the current bar.
                const startIndexForPlotting = msFib.startIndex;
                const relevantData = chartData.slice(startIndexForPlotting);

                const msTopSeries = chart.addLineSeries({ color: msColor, lineWidth: 1, lineStyle: LightweightCharts.LineStyle.Solid, title: `MS ${msFib.type} Top` });
                msTopSeries.setData(relevantData.map(d => ({ time: d.time, value: msFib.top })));
                marketStructureFibonacciLines.push(msTopSeries);

                const msBottomSeries = chart.addLineSeries({ color: msColor, lineWidth: 1, lineStyle: LightweightCharts.LineStyle.Solid, title: `MS ${msFib.type} Bottom` });
                msBottomSeries.setData(relevantData.map(d => ({ time: d.time, value: msFib.bottom })));
                marketStructureFibonacciLines.push(msBottomSeries);

                const msMidSeries = chart.addLineSeries({ color: msColor, lineWidth: 1, lineStyle: LightweightCharts.LineStyle.Dashed, title: `MS ${msFib.type} 0.5` });
                msMidSeries.setData(relevantData.map(d => ({ time: d.time, value: msFib.allLevels['0.500'] })));
                marketStructureFibonacciLines.push(msMidSeries);

                for (const levelKey in msFib.allLevels) {
                    if (levelKey !== '0.000' && levelKey !== '0.500' && levelKey !== '1.000') {
                        const msLevelSeries = chart.addLineSeries({
                            color: msColor.replace('0.8', '0.4'),
                            lineWidth: 1,
                            lineStyle: LightweightCharts.LineStyle.Dotted,
                            title: `MS Fib ${levelKey}`
                        });
                        msLevelSeries.setData(relevantData.map(d => ({ time: d.time, value: msFib.allLevels[levelKey] })));
                        marketStructureFibonacciLines.push(msLevelSeries);
                    }
                }
            }

            // 5. Previous Market Structure Fibs
            previousMarketStructures.forEach((ms, idx) => {
                const opacity = 0.3 + (0.7 * (1 - (idx / previousMarketStructures.length))); // Fade older structures
                const msColor = ms.type === 'bullish' ? 
                    `rgba(8, 153, 129, ${opacity})` : 
                    `rgba(242, 54, 69, ${opacity})`;
                
                // Get the relevant data range for this structure
                const relevantData = chartData.slice(ms.startIndex, ms.endIndex + 1);
                
                // Only plot if we have data points
                if (relevantData.length > 0) {
                    // Plot top and bottom lines
                    const msTopSeries = chart.addLineSeries({ 
                        color: msColor, 
                        lineWidth: 1, 
                        lineStyle: LightweightCharts.LineStyle.Solid, 
                        title: `Previous MS ${idx+1} Top`,
                        visible: false // Initially hidden
                    });
                    msTopSeries.setData(relevantData.map(d => ({ time: d.time, value: ms.top })));
                    previousMarketStructureLines.push(msTopSeries);
                    
                    const msBottomSeries = chart.addLineSeries({ 
                        color: msColor, 
                        lineWidth: 1, 
                        lineStyle: LightweightCharts.LineStyle.Solid, 
                        title: `Previous MS ${idx+1} Bottom`,
                        visible: false
                    });
                    msBottomSeries.setData(relevantData.map(d => ({ time: d.time, value: ms.bottom })));
                    previousMarketStructureLines.push(msBottomSeries);
                    
                    // Plot 0.5 level
                    const msMidSeries = chart.addLineSeries({ 
                        color: msColor, 
                        lineWidth: 1, 
                        lineStyle: LightweightCharts.LineStyle.Dashed, 
                        title: `Previous MS ${idx+1} 0.5`,
                        visible: false
                    });
                    msMidSeries.setData(relevantData.map(d => ({ time: d.time, value: ms.allLevels['0.500'] })));
                    previousMarketStructureLines.push(msMidSeries);
                }
            });

            // 6. Swing Highs and Lows as markers
            currentSwingPoints.allHighs.forEach(sh => {
                swingHighMarkers.push({
                    time: sh.time,
                    position: 'aboveBar',
                    color: '#FFD700',
                    shape: 'circle',
                    text: `Swing High: ${sh.price.toFixed(2)}`
                });
            });
            currentSwingPoints.allLows.forEach(sl => {
                swingLowMarkers.push({
                    time: sl.time,
                    position: 'belowBar',
                    color: '#A9A9A9',
                    shape: 'circle',
                    text: `Swing Low: ${sl.price.toFixed(2)}`
                });
            });
            candleSeries.setMarkers([...smaSignals, ...swingHighMarkers, ...swingLowMarkers]);

            chart.timeScale().fitContent();
            updateTogglesVisibility();
        }

        /**
         * Updates the visibility of chart indicators based on toggle switch states.
         */
        function updateTogglesVisibility() {
            $('#toggleSma').prop('checked', smaSeries && smaSeries.options().visible);
            $('#toggleOverallFib').prop('checked', overallFibonacciLines.length > 0 && overallFibonacciLines[0].options().visible);
            $('#toggleMarketStructureFib').prop('checked', marketStructureFibonacciLines.length > 0 && marketStructureFibonacciLines[0].options().visible);
            $('#togglePreviousMSFib').prop('checked', previousMarketStructureLines.length > 0 && previousMarketStructureLines[0].options().visible);

            const currentMarkers = [];
            if ($('#toggleSmaSignals').prop('checked')) {
                currentMarkers.push(...smaSignalMarkers);
            }
            if ($('#toggleSwingPoints').prop('checked')) {
                currentMarkers.push(...swingHighMarkers, ...swingLowMarkers);
            }
            candleSeries.setMarkers(currentMarkers);
        }

        // --- UI Event Listeners for Toggles ---
        $('#toggleSma').on('change', function() { if (smaSeries) smaSeries.applyOptions({ visible: this.checked }); });
        $('#toggleOverallFib').on('change', function() { overallFibonacciLines.forEach(s => s.applyOptions({ visible: this.checked })); });
        $('#toggleMarketStructureFib').on('change', function() { marketStructureFibonacciLines.forEach(s => s.applyOptions({ visible: this.checked })); });
        $('#togglePreviousMSFib').on('change', function() { previousMarketStructureLines.forEach(s => s.applyOptions({ visible: this.checked })); });
        $('#toggleSwingPoints').on('change', function() {
            updateTogglesVisibility();
        });
        $('#toggleSmaSignals').on('change', function() {
            updateTogglesVisibility();
        });

        // Handles chart resizing to fit container
        window.addEventListener('resize', () => {
            if (chart) {
                chart.resize(document.getElementById('chart-container').clientWidth, document.getElementById('chart-container').clientHeight);
                chart.timeScale().fitContent();
            }
        });

        // Initialize the app by loading symbols when the document is ready
        $(document).ready(() => { loadSymbolsFromApi('NSE'); });
    </script>

    <script>
        // General UI script for hamburger menu and tab functionality (unchanged)
			document.addEventListener('DOMContentLoaded', () => {
			  const hamburger = document.getElementById('hamburger-menu');
			  const navDropdown = document.getElementById('nav-dropdown');

			  hamburger.addEventListener('click', () => {
			    navDropdown.classList.toggle('active');
			  });

			  document.addEventListener('click', (event) => {
			    if (!navDropdown.contains(event.target) && !hamburger.contains(event.target)) {
			      navDropdown.classList.remove('active');
			    }
			  });

			  const tabButtons = document.querySelectorAll('.tab-button');
			  const tabContents = document.querySelectorAll('.tab-content');

			  tabButtons.forEach(button => {
			    button.addEventListener('click', () => {
			      const targetTab = button.dataset.tab;

			      tabButtons.forEach(btn => btn.classList.remove('active'));
			      tabContents.forEach(content => content.classList.remove('active'));

			      button.classList.add('active');
			      document.getElementById(targetTab).classList.add('active');
			    });
			  });

			  if (tabButtons.length > 0) {
			    tabButtons[0].click();
			  }
			});
		</script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboardLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/u756254243/domains/basilstar.com/public_html/resources/views////BasilTrade/chatbot.blade.php ENDPATH**/ ?>
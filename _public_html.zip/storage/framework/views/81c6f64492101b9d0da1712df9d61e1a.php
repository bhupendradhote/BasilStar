

<?php $__env->startSection('content'); ?>
<div class="max-w-6xl mx-auto px-4 mt-8">
    <h2 class="text-2xl font-bold text-gray-800 mb-6">Market Predictions</h2>

    <?php if(session('success')): ?>
        <div class="mb-4 p-3 rounded-md bg-green-100 text-green-700">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php $__empty_1 = true; $__currentLoopData = $predictions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prediction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="bg-white p-6 rounded-xl shadow-md mb-6 relative">
            <div class="flex justify-between items-start mb-4">
                <div>
                    <h3 class="text-xl font-semibold text-gray-800"><?php echo e($prediction->title); ?></h3>
                    <span class="text-sm text-gray-500"><?php echo e($prediction->created_at->format('d M Y, H:i')); ?></span>
                </div>

                <div class="flex space-x-2">
                    <a href="<?php echo e(route('admin.market-prediction.edit', $prediction->id)); ?>" class="px-3 py-1.5 text-sm font-medium text-white bg-yellow-500 rounded hover:bg-yellow-600">
                        <i class="fas fa-edit mr-1"></i> Edit
                    </a>
                    <form action="<?php echo e(route('admin.market-prediction.destroy', $prediction->id)); ?>" method="POST" onsubmit="return confirm('Delete this prediction?');">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="px-3 py-1.5 text-sm font-medium text-white bg-red-600 rounded hover:bg-red-700">
                            <i class="fas fa-trash mr-1"></i> Delete
                        </button>
                    </form>
                </div>
            </div>

            <?php if($prediction->image_url): ?>
                <div class="mb-4">
                    <img src="<?php echo e(asset($prediction->image_url)); ?>" alt="Market Prediction Image" class="w-full rounded-md object-cover max-h-80">
                </div>
            <?php endif; ?>

            <p class="text-gray-700 mb-4"><?php echo e($prediction->description); ?></p>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-gray-800">
                <?php if($prediction->market_sentiment): ?>
                    <div><strong>Sentiment:</strong> <?php echo e($prediction->market_sentiment); ?></div>
                <?php endif; ?>

                <?php if($prediction->range): ?>
                    <div><strong>Expected Range:</strong> <?php echo e($prediction->range); ?></div>
                <?php endif; ?>

                <?php if($prediction->global_cues): ?>
                    <div><strong>Global Cues:</strong> <?php echo e($prediction->global_cues); ?></div>
                <?php endif; ?>

                <?php if($prediction->volatility_alert): ?>
                    <div><strong>Volatility Alert:</strong> <span class="text-red-600"><?php echo e($prediction->volatility_alert); ?></span></div>
                <?php endif; ?>

                <?php if($prediction->support_levels): ?>
                    <div><strong>Support Levels:</strong> <?php echo e($prediction->support_levels); ?></div>
                <?php endif; ?>

                <?php if($prediction->resistance_levels): ?>
                    <div><strong>Resistance Levels:</strong> <?php echo e($prediction->resistance_levels); ?></div>
                <?php endif; ?>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p class="text-gray-600">No predictions found.</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/u756254243/domains/basilstar.com/public_html/resources/views/admin/market_prediction/index.blade.php ENDPATH**/ ?>
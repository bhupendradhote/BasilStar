<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>


	<div class="main-page-wrapper">
		<!--[if lte IE 9]> <p class="browserupgrade"> You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security. </p> <![endif]-->

		<!-- Add your site or application content here -->

		<!-- preloader start -->
		<div id="preloader">
			<div id="ctn-preloader" class="ctn-preloader">
				<div class="txt-loading">
					<span data-text-preloader="B" class="letters-loading">
						B
					</span>
					<span data-text-preloader="a" class="letters-loading">
						a
					</span>
					<span data-text-preloader="s" class="letters-loading">
						s
					</span>
					<span data-text-preloader="i" class="letters-loading">
						i
					</span>
					<span data-text-preloader="l" class="letters-loading">
						l
					</span>
					<span data-text-preloader="S" class="letters-loading">
						S
					</span>
					<span data-text-preloader="t" class="letters-loading">
						t
					</span>
					<span data-text-preloader="a" class="letters-loading">
						a
					</span>
					<span data-text-preloader="r" class="letters-loading">
						r
					</span>
				</div>
			</div>
		</div>
		<!-- preloader end  -->


		<!-- offcanvas start  -->
		<div class="offcanvas offcanvas-top theme-bg" tabindex="-1" id="offcanvasTop">
			<div class="offcanvas-header">
				<a data-bs-dismiss="offcanvas" aria-label="Close">
					<i class="fas fa-times search-close" id="search-close"></i>
				</a>
			</div>
			<div class="offcanvas-body">
				<!-- Fullscreen search -->
				<div class="search-wrap">
					<form method="get">
						<input type="search" class="main-search-input" placeholder="Search Your Keyword...">
					</form>
				</div>
				<!-- end fullscreen search -->
			</div>
		</div>
		<!-- offcanvas end  -->

	
		<!-- shopping-cart-bar end -->



		<!-- slide-bar start -->
		<div class="ht-menu-wrapper">
			<div class="ht-menu-area">
				<button class="ht-menu-toggle"><i class="bi bi-x-lg"></i></button>
				<div class="mobile-logo">
					<a href="index.html">
						<img class="mobile-logo-img" src="assets/img/logo/LogoBasilWhite.png" alt="logo">
					</a>
				</div>
				<div class="mobile-menu-wrapper d-lg-none d-inline-block">
					<div class="mobile-menu"></div>
				</div>
				<div class="offset-widget mb-40">
					<div class="info-widget">
						<h4 class="offset-title mb-20">About Us</h4>
						<p class="mb-30">
							But I must explain to you how all this mistaken idea of denouncing pleasure and
							praising pain was born and will give you a complete account of the system and
							expound the actual teachings of the great explore
						</p>
					</div>
				</div>
				<div class="offset-widget mb-30 pr-10">
					<div class="info-widget info-widget2">
						<h4 class="offset-title mb-20">Contact Info</h4>
						<p>
							<i class="fal fa-address-book"></i>
							23/A, Miranda City Likaoli Prikano, Dope
						</p>
						<p>
							<i class="fal fa-phone"></i>
							+0989 7876 9865 9
						</p>
						<p>
							<i class="fal fa-envelope-open"></i>
							info@example.com
						</p>
					</div>
				</div>
				<div class="login-btn text-center">
					<a class="ht-btn w-100" href="login.html">Login</a>
				</div>

			</div>
		</div>
		<!-- side-bar end -->


		<main>
			<!-- theme-banner-two start -->
			<section class="theme-banner-five">
				<div class="container-fluid px-lg-0">
					<div class="row align-items-center gx-lg-0">
						<div class="col-lg-6 pe-lg-0">
							<h1 class="main-title wow fadeInUp">Top Financial Planning</h1>
							<p class="hero-description me-xxl-5 pe-xxl-5 wow fadeInUp" data-wow-delay="0.1s">Customized
								strategies to maximize wealth,
								reduce risks,
								and
								align finances with your life goals.</p>
							<div class="hero-subscribe-form mb-45 wow fadeInUp" data-wow-delay="0.2s">
								<input type="text" placeholder="Enter Your Mail">
								<button type="submit">Contact Us</button>
							</div>

							<div class="user-content-wrap-1 d-xxl-inline-flex d-none mb-55 wow fadeInUp"
								data-wow-delay="0.3s">
								<ul class="feedback-user-list">
									<li><img src="assets/img/media/media-4.jpg" alt="author"></li>
									<li><img src="assets/img/media/media-5.jpg" alt="author"></li>
									<li><img src="assets/img/media/media-6.jpg" alt="author"></li>
								</ul>
								<div class="rating-box pl-30">
									<div class="hero-rating mb-10">
										<a href="#"><i class="bi bi-star-fill"></i></a>
										<a href="#"><i class="bi bi-star-fill"></i></a>
										<a href="#"><i class="bi bi-star-fill"></i></a>
										<a href="#"><i class="bi bi-star-fill"></i></a>
										<a href="#"><i class="bi bi-star-fill"></i></a>
									</div>
									<h3>13k rating <span>(4.7
											Rating)</span></h3>
								</div>
							</div>
							<div class="d-md-flex align-items-center mb-lg-0 mb-5 wow fadeInUp" data-wow-delay="0.4s">
								<a href="contact.html" class="ht-btn bs-style me-xxl-4">Book a meeting</a>
								<a href="#" class="ht-btn bstyle-2 d-none d-xl-inline-block">Watch Video
									<span class="popup-video ms-xxl-4 ms-2"><i class="bi bi-play-fill"></i></span></a>
							</div>
						</div>
						<div class="col-lg-6 d-flex justify-content-lg-end">
							<div class="hero-img position-relative d-inline-block">
								<img class="main-img img-fluid" src="assets/img/hero/hero-img-6.jpg" alt="Hero">
								<img class="card-shape img-fluid d-none d-xxl-inline-block"
									src="assets/img/hero/card-3.png" alt="shape">
								<img class="card-shape-2 img-fluid d-none d-xxl-inline-block"
									src="assets/img/hero/card-4.png" alt="shape">
							</div>
						</div>
					</div>
				</div><!-- .container -->
			</section>
			<!-- theme-banner-two end -->

			<!-- ht-brand start -->
			<div class="brand-wrap-2 pb-95">
				<div class="container-fluid">
					<div class="row">
						<div class="col-xl-4 item-left mb-xl-0 mb-5">
							<h4><span class="number">Join <strong class="counter fw-medium"> 27,000</strong>+</span>
								companies
								who’ve
								reached </h4>
						</div>
						<div class="col-xl-8 item-right">
							<div class="brand-slide-wrapper ht-carousel" data-slide-show="5" data-lg-slide-show="5"
								data-md-slide-show="3" data-sm-slide-show="2" data-autoplay="true" data-speed="1000"
								data-autoplay-speed="1000">
								<div class="brand-item">
									<a href="#"><img src="assets/img/brand/brand-6.svg" alt="brand"></a>
								</div>
								<div class="brand-item">
									<a href="#"><img src="assets/img/brand/brand-7.svg" alt="brand"></a>
								</div>
								<div class="brand-item">
									<a href="#"><img src="assets/img/brand/brand-8.svg" alt="brand"></a>
								</div>
								<div class="brand-item">
									<a href="#"><img src="assets/img/brand/brand-9.svg" alt="brand"></a>
								</div>
								<div class="brand-item">
									<a href="#"><img src="assets/img/brand/brand-10.svg" alt="brand"></a>
								</div>
								<div class="brand-item">
									<a href="#"><img src="assets/img/brand/brand-6.svg" alt="brand"></a>
								</div>
								<div class="brand-item">
									<a href="#"><img src="assets/img/brand/brand-7.svg" alt="brand"></a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- ht-brand end -->

			<!-- service-section start -->
			<section class="service-section pt-120 pb-60 pt-lg-60 pb-lg-15" data-bg-color="#E4F0F0">
				<div class="container">
					<div class="title-one d-md-flex align-items-center justify-content-between text-center mb-70">
						<h2 class="title wow fadeInLeft">Our Services</h2>
						<a class="ht-btn btn-three wow fadeInRight" href="services.html">All Services</a>
					</div>
					<div class="row gx-50 align-items-center">
						<div class="col-lg-6">
							<div class="service-wrap-6 d-md-flex wow fadeInUp">
								<div class="icon">
									<img class="front-icon" src="assets/img/icon/icon-36.svg" alt="icon">
									<img class="back-icon" src="assets/img/icon/icon-36w.svg" alt="icon">
								</div>
								<div class="content">
									<h4 class="service-title"><a href="services-details.html">Financial Consulting</a>
									</h4>
									<p class="description">Life insurance offers lump sums or payments
										to help beneficiaries cover debts
										and expenses.</p>
									<a href="services-details.html" class="more-btn">View More Details <img
											src="assets/img/icon/arrow-7.svg" alt="arrow"></a>
								</div>
							</div>
						</div>
						<div class="col-lg-6">
							<div class="service-wrap-6 d-md-flex wow fadeInUp">
								<div class="icon">
									<img class="front-icon" src="assets/img/icon/icon-37.svg" alt="icon">
									<img class="back-icon" src="assets/img/icon/icon-37w.svg" alt="icon">
								</div>
								<div class="content">
									<h4 class="service-title"><a href="services-details.html">Business Advisory</a>
									</h4>
									<p class="description">Life insurance offers lump sums or payments
										to help beneficiaries cover debts
										and expenses.</p>
									<a href="services-details.html" class="more-btn">View More Details <img
											src="assets/img/icon/arrow-7.svg" alt="arrow"></a>
								</div>
							</div>
						</div>
						<div class="col-lg-6">
							<div class="service-wrap-6 d-md-flex wow fadeInUp" data-wow-delay="0.1s">
								<div class="icon">
									<img class="front-icon" src="assets/img/icon/icon-38.svg" alt="icon">
									<img class="back-icon" src="assets/img/icon/icon-38w.svg" alt="icon">
								</div>
								<div class="content">
									<h4 class="service-title"><a href="services-details.html">Market Analysis</a>
									</h4>
									<p class="description">Life insurance offers lump sums or payments
										to help beneficiaries cover debts
										and expenses.</p>
									<a href="services-details.html" class="more-btn">View More Details <img
											src="assets/img/icon/arrow-7.svg" alt="arrow"></a>
								</div>
							</div>
						</div>
						<div class="col-lg-6">
							<div class="service-wrap-6 d-md-flex wow fadeInUp" data-wow-delay="0.2s">
								<div class="icon">
									<img class="front-icon" src="assets/img/icon/icon-39.svg" alt="icon">
									<img class="back-icon" src="assets/img/icon/icon-39w.svg" alt="icon">
								</div>
								<div class="content">
									<h4 class="service-title"><a href="services-details.html">Financial Shield</a>
									</h4>
									<p class="description">Life insurance offers lump sums or payments
										to help beneficiaries cover debts
										and expenses.</p>
									<a href="services-details.html" class="more-btn">View More Details <img
											src="assets/img/icon/arrow-7.svg" alt="arrow"></a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
			<!-- service-section end -->

			<!-- about-section start -->
			<section class="about-section pt-140 pb-100 pt-lg-60 pb-lg-20">
				<div class="container">
					<div class="row align-items-center">
						<div class="col-xl-6 col-lg-6 mb-45">
							<div class="img-wrapper-seven wow fadeInLeft">
								<img class="main-img img-fluid" src="assets/img/media/media-34.jpg" alt="About">
								<img class="main-img2 img-fluid d-none d-xl-inline-block"
									src="assets/img/media/media-35.png" alt="About">
							</div>
						</div>
						<div class="col-lg-6 ps-xxl-3 wow fadeInRight">
							<div class="title-one mb-30">
								<h2 class="title">Developing Trust in Finance</h2>
								<p>Enhancing financial trust through accountability, professionalism, and dependable
									solutions tailored to client needs.</p>
							</div>
							<div
								class="border-wrapper pt-40 mb-85 row row-cols-2 row-cols-lg-2 row-cols-md-2 row-cols-1">
								<div class="col">
									<div class="counter-wrap-5 border-wrap">
										<h3 class="number"><span class="counter">130</span>+</h3>
										<p class="counter-title">Earning Honors</p>
									</div>
								</div>
								<div class="col d-md-flex justify-content-center">
									<div class="counter-wrap-5">
										<h3 class="number"><span class="counter">130</span>+</h3>
										<p class="counter-title">Earning Honors</p>
									</div>
								</div>
							</div>
							<a class="ht-btn" href="about.html">About Us</a>
						</div>
					</div>
				</div>
			</section>
			<!-- about-section end -->

			<!-- faq-section start -->
			<section class="faq-section pt-70 pb-25 pt-lg-60 pb-lg-15">
				<div class="container">
					<div class="row">
						<div class="col-xxl-5 col-lg-6">
							<div class="title-one mb-40 wow fadeInUp">
								<h2 class="title">Why Choose us</h2>
								<p class="mb-50">We are here to support you on your financial journey, offering
									dedicated guidance and personalized solutions to ensure
									your success and peace of mind.</p>
								<a class="ht-btn" href="about.html">See More Details</a>
							</div>
						</div>
						<div class="col-lg-6">
							<div class="faq-que-list faq-style-5 mb-45 ps-xxl-5 wow fadeInUp">
								<div class="accordion accordion-one" id="accordion5">
									<div class="accordion-item">
										<h2 class="accordion-header" id="heading5s">
											<button class="accordion-button collapsed" type="button"
												data-bs-toggle="collapse" data-bs-target="#collapse5s"
												aria-expanded="false" aria-controls="collapse5s">
												Global payment options available
											</button>
										</h2>
										<div id="collapse5s" class="accordion-collapse collapse"
											aria-labelledby="heading5s" data-bs-parent="#accordion5">
											<div class="accordion-body">
												<p>We offer various payment methods like credit cards and PayPal,
													prioritizing secure transactions for your information.</p>
											</div>
										</div>
									</div>
									<div class="accordion-item">
										<h2 class="accordion-header" id="headingTwo5s">
											<button class="accordion-button collapsed" type="button"
												data-bs-toggle="collapse" data-bs-target="#collapseTwo5s"
												aria-expanded="false" aria-controls="collapseTwo5s">
												Totally customizable
											</button>
										</h2>
										<div id="collapseTwo5s" class="accordion-collapse collapse"
											aria-labelledby="headingTwo5s" data-bs-parent="#accordion5">
											<div class="accordion-body">
												<p>We offer various payment methods like credit cards and PayPal,
													prioritizing secure transactions for your information.</p>
											</div>
										</div>
									</div>
									<div class="accordion-item">
										<h2 class="accordion-header" id="headingThree5s">
											<button class="accordion-button collapsed" type="button"
												data-bs-toggle="collapse" data-bs-target="#collapseThree5s"
												aria-expanded="false" aria-controls="collapseThree5s">
												Comprehensive Tax and VAT Support
											</button>
										</h2>
										<div id="collapseThree5s" class="accordion-collapse collapse"
											aria-labelledby="headingThree5s" data-bs-parent="#accordion5">
											<div class="accordion-body">
												<p>We offer various payment methods like credit cards and PayPal,
													prioritizing secure transactions for your information.</p>
											</div>
										</div>
									</div>
									<div class="accordion-item">
										<h2 class="accordion-header" id="headingFour5s">
											<button class="accordion-button collapsed" type="button"
												data-bs-toggle="collapse" data-bs-target="#collapseFour5s"
												aria-expanded="false" aria-controls="collapseFour5s">
												Guaranteed safety with secure protection
											</button>
										</h2>
										<div id="collapseFour5s" class="accordion-collapse collapse"
											aria-labelledby="headingFour5s" data-bs-parent="#accordion5">
											<div class="accordion-body">
												<p>We offer various payment methods like credit cards and PayPal,
													prioritizing secure transactions for your information.</p>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
			<!-- faq-section end -->

			<!-- portfolio-section start -->
			
            
            
<section class="portfolio-section position-relative z-1 pt-70 pb-150 pt-lg-60 pb-lg-90">
				<div class="container">
					<div class="row align-items-end justify-content-between mb-40">
						<div class="col-md-7">
							<div class="title-one mb-30">
								<h2 class="title wow fadeInUp">Featured Indicators</h2>
							</div>
						</div>
						<div class="col-md-5 text-lg-end text-center">
							<div class="right-btn mb-30">
								<a class="ht-btn wow fadeInUp" href="project-grid.html">All Indicators</a>
							</div>
						</div>
					</div>
				<div id="arrow-nav-7" class="row gx-50 ht-carousel align-items-center" data-slide-show="2"
            	data-lg-slide-show="2" data-md-slide-show="2" data-xs-slide-show="1">
            
                <?php $__empty_1 = true; $__currentLoopData = $featuredIndicators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $indicator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-lg-6">
                        <div class="portfolio-wrap-2">
                            <div class="portfolio-thumb">
                                <img src="<?php echo e(asset('/storage/app/public/' . json_decode($indicator->images)[0])); ?>" alt="portfolio">
                                <a class="icon-link" href="<?php echo e(route('admin.products.show', $indicator->id)); ?>">
                                    <img src="<?php echo e(asset('assets/img/icon/arrow-9.svg')); ?>" alt="arrow">
                                </a>
                            </div>
                            <div class="content">
                                <a href="<?php echo e(route('admin.products.show', $indicator->id)); ?>" class="pf-tag"><?php echo e($indicator->category ?? 'Advisory'); ?></a>
                                <h3 class="pf-title">
                                    <a href="<?php echo e(route('admin.products.show', $indicator->id)); ?>"><?php echo e($indicator->name); ?></a>
                                </h3>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-12 text-center">
                        <p>No featured indicators found.</p>
                    </div>
                <?php endif; ?>
            </div>
				</div>
				<div class="container">
					<div class="feature-slider-wrap mt-50">
						<div class="feature-arrow-border"></div>
						<div class="arrow-style-2 d-inline-flex align-items-center justify-content-end  z-2 px-4 end-0 mr-130"
							data-bg-color="#E4F0F0">
							<button data-slick-prev="#arrow-nav-7" class="slick-prev slick-arrow mr-15">
								<img src="assets/img/icon/arrow-left-2.svg" alt="arrow">
							</button>
							<button data-slick-next="#arrow-nav-7" class="slick-next slick-arrow">
								<img src="assets/img/icon/arrow-right-2.svg" alt="arrow">
							</button>
						</div>
					</div>
				</div>
				<div class="portfolio-section-bg" data-bg-color="#E4F0F0"></div>
			</section>


			<!-- portfolio-section end -->


			<!-- feedback-section start -->
			<div class="feedback-section position-relative z-1 pt-120 pt-lg-60 pb-70 pb-lg-60">
				<div class="container">
					<div class="row">
						<div class="col-lg-5 position-relative mb-45 d-flex flex-column justify-content-between">
							<div class="title-one mb-5">
								<h2 class="title">Words from clients.</h2>
							</div>
							<div class="number-wrapper">
								<div class="number-pagination">0<span class="pagingInfo1"></span></div>
								<div class="divider-line"></div>
								<div class="total-pagination">0<span class="pagingInfo2"></span></div>
							</div>
						</div>
						<div class="col-lg-7 mb-45">
							<div class="ht-carousel-2 feedback-slider-five">
								<div class="feedback-wrap-6">
									<p class="feedback-text">This platform has completely changed how I manage finances,
										offering expert advice and user-friendly tools that enabled me to achieve my
										investment goals effectively and efficiently.</p>
									<div class="author-info d-flex align-items-center">
										<div class="author-avatar">
											<img src="assets/img/media/media-37.jpg" alt="author">
										</div>
										<div class="author-content">
											<h4 class="name">John cuper jonathan</h4>
											<p class="designation">California, USA</p>
										</div>
									</div>
									<div class="quote-icon">
										<img src="assets/img/icon/icon-40.svg" alt="quote">
									</div>
								</div>
								<div class="feedback-wrap-6">
									<p class="feedback-text">This platform has completely changed how I manage finances,
										offering expert advice and user-friendly tools that enabled me to achieve my
										investment goals effectively and efficiently.</p>
									<div class="author-info d-flex align-items-center">
										<div class="author-avatar">
											<img src="assets/img/media/media-37.jpg" alt="author">
										</div>
										<div class="author-content">
											<h4 class="name">John cuper jonathan</h4>
											<p class="designation">California, USA</p>
										</div>
									</div>
									<div class="quote-icon">
										<img src="assets/img/icon/icon-40.svg" alt="quote">
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- feedback-section end -->

			<!-- contact-section-one end -->
			<section class="grey-bg contact-section pt-120 pb-120 pt-lg-60 pb-lg-60">
				<div class="container">
					<div class="contact-bg-one p-3">
						<div class="row">
							<div class="col-xl-6 col-lg-6 pe-lg-0">
								<div class="contact-form-wrapper-2">
									<div class="title-one mb-30">
										<h2 class="title">Contact Us.</h2>
									</div>
									<form class="contact-form" action="#">
										<div class="input-wrapper">
											<input type="text" placeholder="Name*">
										</div>
										<div class="input-wrapper">
											<input type="email" placeholder="Email*">
										</div>
										<div class="input-wrapper">
											<input type="number" placeholder="Phone*">
										</div>
										<div class="input-wrapper message">
											<textarea name="message" placeholder="Your Message"></textarea>
										</div>
										<button type="submit" class="submit-btn border-0">Contact
											Us</button>
									</form>
								</div>
							</div>
							<div class="col-xl-6 col-lg-6">
								<div class="contact-img-box text-lg-end">
									<img class="img-fluid" src="assets/img/media/media-36.jpg" alt="media">
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
			<!-- contact-section-one end -->

			<!-- blog-section start -->
			<!-- <section class="blog-section pt-140 pb-175 pt-lg-60 pb-lg-90">
				<div class="container">
					<div class="row mb-40 align-items-center">
						<div class="col-md-7">
							<div class="title-one text-lg-start text-center mb-30">
								<h2 class="title wow fadeInLeft">Our Recent Blogs</h2>
							</div>
						</div>
						<div class="col-md-5">
							<div class="right-btn text-md-end text-center mb-30">
								<a href="blog-grid.html" class="ht-btn wow fadeInRight">Explore All blogs</a>
							</div>
						</div>
					</div>

					<div id="arrow-nav-8" class="row ht-carousel gx-50 align-items-center justify-content-center"
						data-slide-show="3" data-lg-slide-show="3" data-md-slide-show="2" data-xs-slide-show="1">
						<div class="col-lg-4">
							<div class="blog-seven">
								<div class="blog-thumb">
									<a href="blog-details.html" class="blog-tag">Investment</a>
									<img src="assets/img/blog/blog-9.jpg" alt="blog">
									<a href="blog-details.html" class="blog-btn"><img
											src="assets/img/icon/arrow-right-2.svg" alt=""></a>
								</div>
								<div class="blog-content">
									<div class="blog-meta">
										<a href="blog-details.html">Rodela Jahan</a>
										<span class="divider"></span>
										<a href="blog-details.html">15 Oct 2024</a>
									</div>

									<h4 class="blog-title"><a href="blog-details.html">Steps to use the investment
											growth calculator</a>
									</h4>

								</div>
							</div>
						</div>
						<div class="col-lg-4">
							<div class="blog-seven">
								<div class="blog-thumb">
									<a href="blog-details.html" class="blog-tag">Business</a>
									<img src="assets/img/blog/blog-10.jpg" alt="blog">
									<a href="blog-details.html" class="blog-btn"><img
											src="assets/img/icon/arrow-right-2.svg" alt=""></a>
								</div>
								<div class="blog-content">
									<div class="blog-meta">
										<a href="blog-details.html">Jenny Smith</a>
										<span class="divider"></span>
										<a href="blog-details.html">15 Oct 2024</a>
									</div>

									<h4 class="blog-title"><a href="blog-details.html">Helpful advice for planning a
											business budget</a>
									</h4>
								</div>
							</div>
						</div>
						<div class="col-lg-4">
							<div class="blog-seven">
								<div class="blog-thumb">
									<a href="blog-details.html" class="blog-tag">Tax Planning</a>
									<img src="assets/img/blog/blog-11.jpg" alt="blog">
									<a href="blog-details.html" class="blog-btn"><img
											src="assets/img/icon/arrow-right-2.svg" alt=""></a>
								</div>
								<div class="blog-content">
									<div class="blog-meta">
										<a href="blog-details.html">Lisa Mir</a>
										<span class="divider"></span>
										<a href="blog-details.html">15 Oct 2024</a>
									</div>

									<h4 class="blog-title"><a href="blog-details.html">Strong Financial Practices
											Essential for Organizations</a>
									</h4>
								</div>
							</div>
						</div>
						<div class="col-lg-4">
							<div class="blog-seven">
								<div class="blog-thumb">
									<a href="blog-details.html" class="blog-tag">Investment</a>
									<img src="assets/img/blog/blog-9.jpg" alt="blog">
									<a href="blog-details.html" class="blog-btn"><img
											src="assets/img/icon/arrow-right-2.svg" alt=""></a>
								</div>
								<div class="blog-content">
									<div class="blog-meta">
										<a href="blog-details.html">Rodela Jahan</a>
										<span class="divider"></span>
										<a href="blog-details.html">15 Oct 2024</a>
									</div>

									<h4 class="blog-title"><a href="blog-details.html">Steps to use the investment
											growth calculator</a>
									</h4>

								</div>
							</div>
						</div>
						<div class="col-lg-4">
							<div class="blog-seven">
								<div class="blog-thumb">
									<a href="blog-details.html" class="blog-tag">Business</a>
									<img src="assets/img/blog/blog-10.jpg" alt="blog">
									<a href="blog-details.html" class="blog-btn"><img
											src="assets/img/icon/arrow-right-2.svg" alt=""></a>
								</div>
								<div class="blog-content">
									<div class="blog-meta">
										<a href="blog-details.html">Jenny Smith</a>
										<span class="divider"></span>
										<a href="blog-details.html">15 Oct 2024</a>
									</div>

									<h4 class="blog-title"><a href="blog-details.html">Helpful advice for planning a
											business budget</a>
									</h4>
								</div>
							</div>
						</div>
						<div class="col-lg-4">
							<div class="blog-seven">
								<div class="blog-thumb">
									<a href="blog-details.html" class="blog-tag">Tax Planning</a>
									<img src="assets/img/blog/blog-11.jpg" alt="blog">
									<a href="blog-details.html" class="blog-btn"><img
											src="assets/img/icon/arrow-right-2.svg" alt=""></a>
								</div>
								<div class="blog-content">
									<div class="blog-meta">
										<a href="blog-details.html">Lisa Mir</a>
										<span class="divider"></span>
										<a href="blog-details.html">15 Oct 2024</a>
									</div>

									<h4 class="blog-title"><a href="blog-details.html">Strong Financial Practices
											Essential for Organizations</a>
									</h4>
								</div>
							</div>
						</div>
					</div>
					<div class="feature-slider-wrap border-arrow-2 mt-50">
						<div class="feature-arrow-border"></div>
						<div class="arrow-style-2 d-inline-flex align-items-center justify-content-center z-2 px-4"
							data-bg-color="#fff">
							<button data-slick-prev="#arrow-nav-8" class="slick-prev slick-arrow mr-15">
								<img src="assets/img/icon/arrow-left-2.svg" alt="arrow">
							</button>
							<button data-slick-next="#arrow-nav-8" class="slick-next slick-arrow">
								<img src="assets/img/icon/arrow-right-2.svg" alt="arrow">
							</button>
						</div>
					</div>
				</div>
			</section> -->
			<!-- blog-section end -->


			<!-- cta start -->
			<div class="cta-section position-relative z-2">
				<div class="container">
					<div class="row align-items-center theme-bg border-rad pt-75 pb-45">
						<div class="col-md-7">
							<div class="title-one text-md-start text-center mb-30 ps-xxl-5">
								<h2 class="title text-dark">Book a Meeting</h2>
							</div>
						</div>
						<div class="col-md-5">
							<div class="right-btn text-center text-md-end mb-30 pe-xxl-5 position-relative z-1">
								<a class="ht-btn style-2" href="contact.html">Book now</a>
								<img class="position-absolute rotation start-0 mt-50"
									src="assets/img/shape/shape-11.png" alt="shape">
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- cta end -->



		</main>


		

		<!-- Modal -->
	

		<!--scrollToTopBtn end-->
		<a id="scrollToTopBtn" class="progress-wrap">
			<i class="bi bi-arrow-up"></i>
		</a>


	</div>


    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/u756254243/domains/basilstar.com/public_html/resources/views////index.blade.php ENDPATH**/ ?>
    

    <?php $__env->startSection('title', 'liveChart'); ?>

    <?php $__env->startSection('content'); ?>

    
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            if (localStorage.getItem('showAlert') === 'true') {
                Swal.fire({
                    title: 'Login Successful!',
                    text: 'Welcome to the live chart.',
                    icon: 'success',
                    confirmButtonText: 'OK',
                    confirmButtonColor: '#007bff',
                }).then(() => {
                    localStorage.removeItem('showAlert'); // Remove the flag after showing the alert
                });
            }
        });
    </script>

    

    <div id="controls">
        <div class="control-group">
            <label for="exchange">Exchange:</label>
            <select id="exchange">
                <option value="NSE">NSE</option>
                <option value="BSE">BSE</option>
                <option value="NASDAQ">NASDAQ</option>
                <option value="NYSE">NYSE</option>
            </select>
        </div>

        <div class="control-group">
            <label for="symbol">Symbol:</label>
            <select id="symbol" style="width: 200px;">
                <option value="INFY">INFY</option>
            </select>
        </div>

        <div class="control-group">
            <label for="periodicity">Periodicity:</label>
            <select id="periodicity">
                <option value="Minute">Minute</option>
                <option value="Hour">Hour</option>
                <option value="Day" selected>Day</option>
                <option value="Week">Week</option>
                <option value="Month">Month</option>
            </select>
        </div>

        <div class="control-group">
            <label for="barSize">Bar Size:</label>
            <select id="barSize">
                <option value="1" selected>1</option>
                <option value="5">5</option>
                <option value="15">15</option>
                <option value="30">30</option>
                <option value="60">60</option>
            </select>
        </div>

        <div class="control-group">
            <label for="period">Period:</label>
            <select id="period">
                <option value="1">1</option>
                <option value="5">5</option>
                <option value="10">10</option>
                <option value="30" selected>30</option>
                <option value="60">60</option>
                <option value="90">90</option>
            </select>
        </div>
        <div class="control-group">
            <label for="chartType">Chart Type:</label>
            <select id="chartType">
                <option value="line" selected>Line</option>
                <option value="candle">Candlestick</option>
            </select>
        </div>
        <button id="refreshBtn">Refresh Data</button>
    </div>

    <div id="chart"></div>
    <div id="output">Connecting...</div>
    <div class="detailed_analysis">
        <div class="current_ohlcv"></div>
        <div class="past_ohlcv"></div>
        <div class="ma_anslysis"></div>
        <div class="mo_anslysis"></div>
        <div class="to_anslysis"></div>
        <div class="return_anslysis"></div>
        <div class="sr_anslysis"></div>
        <div class="mood_anslysis">
            <canvas id="moodGauge" width="200" height="120"></canvas>
        </div>
    </div>
    <!-- <script src="/BasilTrade/assets/js/analysis/currentOHLCV.js"></script>
    <script src="/BasilTrade/assets/js/chart/chartUtils.js"></script>
    <script src="/BasilTrade/assets/js/chart/chart.js"></script>
    <script src="/BasilTrade/assets/js/analysis/movingAverages.js"></script>
    <script src="/BasilTrade/assets/js/analysis/momentumOscillators.js"></script>
    <script src="/BasilTrade/assets/js/analysis/trendOscillators.js"></script>
    <script src="/BasilTrade/assets/js/analysis/returnsAnalysis.js"></script>
    <script src="/BasilTrade/assets/js/analysis/supportResistanceAnalysis.js"></script>
    <script src="/BasilTrade/assets/js/analysis/stockTrendAnalysis.js"></script> -->

    <?php $__env->stopSection(); ?>
    
<?php echo $__env->make('layouts.dashboardLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/u756254243/domains/basilstar.com/public_html/resources/views////BasilTrade/liveChart.blade.php ENDPATH**/ ?>
<!-- Sidebar -->
<nav id="sidebar" class="active">
    <div class="sidebar-header">
        <h3>Admin Panel</h3>
        <strong>AP</strong>
    </div>

    <ul class="list-unstyled components">
        <li class="<?php echo e(request()->is('admin/dashboard') ? 'active' : ''); ?>">
            <a href="/admin/dashboard">
                <i class="fas fa-tachometer-alt"></i>
                Dashboard
            </a>
        </li>
        
        <li class="<?php echo e(request()->is('admin/users*') ? 'active' : ''); ?>">
            <a href="#">
                <i class="fas fa-users"></i>
                Users
            </a>
        </li>
        
        <li class="<?php echo e(request()->is('admin/products*') ? 'active' : ''); ?>">
            <a href="/admin/products">
                <i class="fas fa-boxes"></i>
                Products
            </a>
        </li>
        <li class="<?php echo e(request()->is('admin/orders*') ? 'active' : ''); ?>">
            <a href="#">
                <i class="fas fa-shopping-cart"></i>
                Orders
            </a>
        </li>
        
        <li class="<?php echo e(request()->is('admin/settings*') ? 'active' : ''); ?>">
            <a href="#">
                <i class="fas fa-cog"></i>
                Settings
            </a>
        </li>
        
        <!-- Additional static menu items -->
        <li>
            <a href="#">
                <i class="fas fa-chart-bar"></i>
                Reports
            </a>
        </li>
        
        <li>
            <a href="#">
                <i class="fas fa-envelope"></i>
                Messages
                <span class="badge bg-primary float-end">5</span>
            </a>
        </li>
    </ul>
</nav><?php /**PATH /home/u756254243/domains/basilstar.com/public_html/resources/views/admin/partials/sidebar.blade.php ENDPATH**/ ?>
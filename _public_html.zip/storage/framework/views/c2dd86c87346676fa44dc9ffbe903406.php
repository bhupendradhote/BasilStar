

<?php $__env->startSection('content'); ?>
<div class="max-w-6xl mx-auto mt-10 px-4">
    <h2 class="text-2xl font-bold mb-6 text-gray-800">All Market Baskets</h2>

    <?php if(session('success')): ?>
        <div class="mb-4 p-3 rounded-md bg-green-100 text-green-700">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <div class="mb-6 text-right">
        <a href="<?php echo e(route('admin.basket.create')); ?>" class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
            + Create New Basket
        </a>
    </div>

    <?php $__empty_1 = true; $__currentLoopData = $baskets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $basket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="bg-white shadow rounded-lg mb-6 p-4">
            <div class="flex justify-between items-center mb-3">
                <h3 class="text-lg font-semibold text-gray-800"><?php echo e($basket->basket_type); ?> Basket</h3>
                <div class="flex gap-2">
                    <a href="<?php echo e(route('admin.basket.edit', $basket->id)); ?>" class="text-blue-600 hover:underline">Edit</a>
                    <form action="<?php echo e(route('admin.basket.destroy', $basket->id)); ?>" method="POST" onsubmit="return confirm('Are you sure you want to delete this basket?')">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="text-red-600 hover:underline">Delete</button>
                    </form>
                </div>
            </div>

            <table class="w-full text-sm border border-gray-200 rounded overflow-hidden">
                <thead class="bg-gray-100 text-gray-700">
                    <tr>
                        <th class="p-2 text-left">Symbol</th>
                        <th class="p-2 text-left">Buy Price (₹)</th>
                        <th class="p-2 text-left">Target (₹)</th>
                        <th class="p-2 text-left">Stop Loss (₹)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $basket->stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="border-t">
                            <td class="p-2"><?php echo e($stock->symbol); ?></td>
                            <td class="p-2"><?php echo e($stock->buy_price); ?></td>
                            <td class="p-2"><?php echo e($stock->target_price); ?></td>
                            <td class="p-2"><?php echo e($stock->stop_loss); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p class="text-gray-600">No baskets available.</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/u756254243/domains/basilstar.com/public_html/resources/views/admin/baskets/index.blade.php ENDPATH**/ ?>
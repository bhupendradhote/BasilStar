
<?php $__env->startSection('title', 'All Market Predictions'); ?>
<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h3 class="mb-4 text-primary fw-bold predictions_heading">All Market Predictions</h3>

    <?php $__empty_1 = true; $__currentLoopData = $predictions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prediction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="card mb-4 shadow-sm prediction-card">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-start mb-3">
                    <h5 class="card-title text-dark mb-0"><?php echo e($prediction->title); ?></h5>
                    <small class="text-muted fst-italic"><?php echo e($prediction->created_at->format('d M Y, H:i')); ?></small>
                </div>

                <?php if($prediction->image_url): ?>
                    <div class="text-center mb-3 mt-3">
                        <img src="<?php echo e(asset($prediction->image_url)); ?>" alt="Prediction Image" class="img-fluid rounded prediction-image">
                    </div>
                <?php endif; ?>

                <p class="card-text text-secondary"><?php echo e($prediction->description); ?></p>

                <ul class="list-unstyled small mt-3 border-top pt-3">
                    <?php if($prediction->range): ?>
                        <li class="mb-1"><strong>Range:</strong> <span class="text-info"><?php echo e($prediction->range); ?></span></li>
                    <?php endif; ?>
                    <?php if($prediction->market_sentiment): ?>
                        <li class="mb-1"><strong>Sentiment:</strong> <span class="text-success"><?php echo e($prediction->market_sentiment); ?></span></li>
                    <?php endif; ?>
                    <?php if($prediction->global_cues): ?>
                        <li class="mb-1"><strong>Global Cues:</strong> <span class="text-muted"><?php echo e($prediction->global_cues); ?></span></li>
                    <?php endif; ?>
                    <?php if($prediction->volatility_alert): ?>
                        <li class="mb-1"><strong>Volatility:</strong> <span class="text-danger fw-bold"><?php echo e($prediction->volatility_alert); ?></span></li>
                    <?php endif; ?>
                    <?php if($prediction->support_levels): ?>
                        <li class="mb-1"><strong>Support:</strong> <span class="text-primary"><?php echo e($prediction->support_levels); ?></span></li>
                    <?php endif; ?>
                    <?php if($prediction->resistance_levels): ?>
                        <li class="mb-1"><strong>Resistance:</strong> <span class="text-danger"><?php echo e($prediction->resistance_levels); ?></span></li>
                    <?php endif; ?>
                </ul>
            </div>
            
        </div>
        <hr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="alert alert-info text-center" role="alert">
            No predictions found. Check back later!
        </div>
    <?php endif; ?>
</div>

<style>
.container{
    padding: 15px;
}
    .prediction-card {
        transition: transform 0.2s ease-in-out;
    }

    .prediction-image {
            max-height: 300px;
    object-fit: cover;
    width: 100%;
    border-radius: 8px;
    margin: 10px 0;
    border: 1px solid #ccc;
    }
    .card-title {
        color: rgb(74 222 128 / var(--tw-text-opacity, 1));;
    }
    
    .card-text {
        line-height: 1.6; /* Improve readability of description */
    }
    .list-unstyled li {
        padding-left: 0.5rem; /* Indent list items slightly */
    }
    .predictions_heading {
    font-size: 26px;
    margin-bottom: 15px;
}
.card  {
    box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px;
    padding: 10px;
    border-radius: 10px;
    margin:  10px 0;
}

</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboardLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/u756254243/domains/basilstar.com/public_html/resources/views/allMarketPredictions.blade.php ENDPATH**/ ?>